const puppeteer = require('puppeteer');
const Inoculation = require('../models/Inoculation');
const Appointment = require('../models/Appointment');
const Patient = require("../models/Patient");
const Vaccine = require('../models/Vaccine');
const Doctor = require('../models/Doctor');
const Clinic = require('../models/Clinic')

const { Document, Packer, Paragraph, TextRun, HeadingLevel } = require("docx");


exports.generateCertificate = async (req, res) => {
    try {
        const vaccineId = parseInt(req.body.vaccine_id);
        const data = req.body.vaccinationData;

        if (!Array.isArray(data)) {
            return res.status(400).json({ message: "Поле vaccinationData має бути масивом." });
        }

        const record = data.find(v => v.vaccine_id === vaccineId);
        if (!record) {
            return res.status(404).json({ message: "Дані по заданому vaccine_id не знайдено." });
        }

        const patient = record.patient;
        const clinic = record.clinic;
        const doctor = record.doctor;
        const appointments = record.appointments;

        const doc = new Document({
            sections: [{
                children: [
                    new Paragraph({
                        text: "Довідка про щеплення",
                        heading: HeadingLevel.HEADING1,
                        alignment: "center"
                    }),
                    new Paragraph({ text: `Пацієнт: ${patient.lastname} ${patient.name}` }),
                    new Paragraph({ text: `Дата народження: ${new Date(patient.birthday).toLocaleDateString()}` }),
                    new Paragraph({ text: `Клініка: ${clinic.name}, ${clinic.city}, ${clinic.address}`, spacing: { after: 300 } }),

                    new Paragraph({
                        text: `Вакцина: ${record.vaccine_name}`,
                        heading: HeadingLevel.HEADING2
                    }),
                    new Paragraph({ text: "Список щеплень:", heading: HeadingLevel.HEADING3 }),

                    ...appointments.map(app =>
                        new Paragraph({
                            children: [
                                new TextRun({ text: `${app.dose_number} доза`, bold: true }),
                                new TextRun({ text: `\nДата: ${new Date(app.appointment_datetime).toLocaleString()}` }),
                                new TextRun({ text: `\nЛікар: ${doctor.lastname} ${doctor.name}` }),
                            ],
                            spacing: { after: 200 }
                        })
                    ),

                    ...(record.message1 ? [new Paragraph({ text: record.message1 })] : [])
                ]
            }]
        });


        const buffer = await Packer.toBuffer(doc);

        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        res.setHeader("Content-Disposition", "attachment; filename=certificate.docx");
        res.send(buffer);
    } catch (error) {
        console.error("Помилка при створенні довідки:", error);
        res.status(500).json({ message: 'Помилка створення довідки' });
    }
};

