const Clinic = require('../models/Clinic');
const {Op} = require("sequelize");

// Отримати всі медичні заклади
const getAll = async (req, res) => {
    try {
        const clinics = await Clinic.findAll();
        res.json(clinics);
    } catch (err) {
        console.error('Помилка при отриманні закладів:', err);
        res.status(500).send('Помилка сервера');
    }
};

// Отримати один заклад за ID
const getById = async (req, res) => {
    try {
        const clinic = await Clinic.findByPk(req.params.id);
        if (!clinic) {
            return res.status(404).send('Заклад не знайдено');
        }
        res.json(clinic);
    } catch (err) {
        console.error('Помилка при пошуку закладу:', err);
        res.status(500).send('Помилка сервера');
    }
};

// Створити новий медичний заклад
const create = async (req, res) => {
    try {
        const { name, city, address, description } = req.body;

        const newClinic = await Clinic.create({
            name,
            city,
            address,
            description
        });

        res.status(201).json(newClinic);
    } catch (err) {
        console.error('Помилка при створенні закладу:', err);
        res.status(500).send('Помилка сервера');
    }
};

const getByCity = async (req, res) => {
    try {
        const cityName = req.query.city;

        if (!cityName) {
            return res.status(400).send('Параметр "city" є обовʼязковим');
        }

        const clinics = await Clinic.findAll({
            where: {
                city: {
                    [Op.like]: `%${cityName}%` // або Op.like для нечутливого до регістру пошуку в SQLite / MySQL
                }
            }
        });

        res.json(clinics);
    } catch (err) {
        console.error('Помилка при пошуку клінік за містом:', err);
        res.status(500).send('Помилка сервера');
    }
};

const update = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, city, address, description } = req.body;

        const clinic = await Clinic.findByPk(id);
        if (!clinic) {
            return res.status(404).send('Клініку не знайдено');
        }

        if (name !== undefined) clinic.name = name;
        if (city !== undefined) clinic.city = city;
        if (address !== undefined) clinic.address = address;
        if (description !== undefined) clinic.description = description;

        await clinic.save();

        res.json(clinic);
    } catch (err) {
        console.error('Помилка при оновленні клініки:', err);
        res.status(500).send('Помилка сервера');
    }
};


const remove = async (req, res) => {
    try {
        const { id } = req.params;

        const clinic = await Clinic.findByPk(id);
        if (!clinic) {
            return res.status(404).send('Клініку не знайдено');
        }

        await clinic.destroy();
        res.send('Клініку успішно видалено');
    } catch (err) {
        console.error('Помилка при видаленні клініки:', err);
        res.status(500).send('Помилка сервера');
    }
};


module.exports = {
    getAll,
    getById,
    create,
    getByCity,
    update,
    remove
};
