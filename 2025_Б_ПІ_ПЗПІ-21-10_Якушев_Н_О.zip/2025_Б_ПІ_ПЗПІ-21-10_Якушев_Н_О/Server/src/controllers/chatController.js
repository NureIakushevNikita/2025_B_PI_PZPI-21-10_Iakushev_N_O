// controllers/chatController.js
const axios = require('axios');

const askChat = async (req, res) => {
    const { question } = req.body;
    const base = "Дай відповідь на питання, пов'язане з вакцинацією та щепленнями українською мовою."

    if (!question) {
        return res.status(400).json({ error: 'Питання є обов’язковим' });
    }

    try {
        const response = await axios.post(
            'https://openrouter.ai/api/v1/chat/completions',
            {
                model: 'mistralai/devstral-small:free',
                messages: [{ role: 'user', content: `${base} ${question}` }],
            },
            {
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        const answer = response.data.choices[0].message.content;
        res.json({ answer });
    } catch (error) {
        console.error('Помилка OpenRouter:', error.response?.data || error.message);
        res.status(500).json({ error: 'Помилка отримання відповіді від AI' });
    }
};

module.exports = { askChat };
