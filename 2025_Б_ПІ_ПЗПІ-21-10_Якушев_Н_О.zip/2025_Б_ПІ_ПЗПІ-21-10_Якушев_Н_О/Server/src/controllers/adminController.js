const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret';

const registerAdmin = async (req, res) => {
    try {
        const { name, lastname, email, password } = req.body;

        const existingAdmin = await Admin.findOne({ where: { email } });
        if (existingAdmin) {
            return res.status(400).json({ message: 'Користувач з таким email вже існує' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newAdmin = await Admin.create({
            name,
            lastname,
            email,
            password: hashedPassword
        });

        res.status(201).json({ message: 'Адміністратора створено успішно', admin: { id: newAdmin.id, email: newAdmin.email } });
    } catch (error) {
        console.error('Помилка при створенні адміністратора:', error);
        res.status(500).json({ message: 'Внутрішня помилка сервера' });
    }
};

const loginAdmin = async (req, res) => {
    try {
        const { email, password } = req.body;

        const admin = await Admin.findOne({ where: { email } });
        if (!admin) {
            return res.status(401).json({ message: 'Невірний email або пароль' });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Невірний email або пароль' });
        }

        const token = jwt.sign({ id: admin.id, role: 'admin' }, JWT_SECRET, { expiresIn: '12h' });

        res.json({
            message: 'Авторизація успішна',
            token,
            admin: {
                id: admin.id,
                name: admin.name,
                lastname: admin.lastname,
                email: admin.email
            }
        });
    } catch (error) {
        console.error('Помилка при авторизації:', error);
        res.status(500).json({ message: 'Внутрішня помилка сервера' });
    }
};

const verifyPassword = async (req, res) => {
    try {
        const { password } = req.body;
        const adminId = req.user.id;

        if (!password) {
            return res.status(400).json({ success: false, message: 'Пароль обовʼязковий' });
        }

        const admin = await Admin.findByPk(adminId);
        if (!admin) {
            return res.status(404).json({ success: false, message: 'Адміністратор не знайдений' });
        }

        const isMatch = await bcrypt.compare(password, admin.password);

        res.json({ success: isMatch });
    } catch (err) {
        console.error('Помилка при перевірці пароля:', err);
        res.status(500).send('Помилка сервера');
    }
};

module.exports = {
    registerAdmin,
    loginAdmin,
    verifyPassword
};
