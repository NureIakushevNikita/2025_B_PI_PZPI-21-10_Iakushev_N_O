const Doctor = require('../models/Doctor');
const {hash, compare} = require("bcrypt");
const Clinic = require("../models/Clinic");
const jwt = require('jsonwebtoken');
const {EmailClient} = require("@azure/communication-email");
const Patient = require("../models/Patient");
const connectionString = process.env.AZURE_COM_SERVICE_CONN_STR;
const emailClient = new EmailClient(connectionString);

// Отримати всіх лікарів
const getAll = async (req, res) => {
    try {
        const doctors = await Doctor.findAll({
            attributes: { exclude: ['password'] },
            include: {
                model: Clinic,
                as: 'clinic' // якщо є alias у зв'язку, інакше прибери цей рядок
            }
        });
        res.json(doctors);
    } catch (err) {
        console.error('Помилка при отриманні лікарів:', err);
        res.status(500).send('Помилка сервера');
    }
};

// Отримати лікаря за ID
const getById = async (req, res) => {
    try {
        const doctor = await Doctor.findByPk(req.params.id);
        if (!doctor) {
            return res.status(404).send('Лікаря не знайдено');
        }
        res.json(doctor);
    } catch (err) {
        console.error('Помилка при пошуку лікаря:', err);
        res.status(500).send('Помилка сервера');
    }
};

const update = async (req, res) => {
    try {
        const doctor = await Doctor.findByPk(req.params.id);
        if (!doctor) {
            return res.status(404).send('Лікаря не знайдено');
        }

        await doctor.update(req.body);

        // Повторно завантажуємо лікаря з приєднаною клінікою
        const updatedDoctor = await Doctor.findByPk(req.params.id, {
            include: {
                model: Clinic,
                as: 'clinic',
                attributes: ['id', 'name'] // або усі потрібні поля
            }
        });

        res.json(updatedDoctor);
    } catch (err) {
        console.error('Помилка при оновленні лікаря:', err);
        res.status(500).send('Помилка сервера');
    }
};


const create = async (req, res) => {
    try {
        const { email, password, ...otherData } = req.body;

        const existing = await Doctor.findOne({ where: { email } });
        if (existing) {
            return res.status(400).send('Лікар з такою електронною поштою вже існує');
        }

        const hashedPassword = await hash(password, 10);

        let newDoctor = await Doctor.create({
            ...otherData,
            email,
            password: hashedPassword
        });

        // Перезавантажити модель з включенням clinic
        newDoctor = await newDoctor.reload({ include: { model: Clinic, as: 'clinic' } });

        // Видалити пароль з результату
        const { password: _, ...doctorWithoutPassword } = newDoctor.get({ plain: true });

        res.status(201).json(doctorWithoutPassword);

        const subject = `Реєстрація в системі VacHealth`;
        const htmlContent = `
            <strong>Шановний ${doctorWithoutPassword.name} ${doctorWithoutPassword.lastname}!</strong><br>
            Вас зареєстровано в системі VacHealth</strong><br>
            Електронна пошта для авторизації: ${doctorWithoutPassword.email}<br>
            Пароль для авторизації: ${password}<br>
            <strong>Обов'язково змініть пароль після першої авторизації</strong>
        `;

        const message = {
            senderAddress: "DoNotReply@2152cdd7-d517-4bb8-b3e5-51a688df7fa9.azurecomm.net",
            content: {
                subject,
                html: htmlContent,
                plainText: `Вас зареєстровно в системі VacHealth`
            },
            recipients: {
                to: [
                    {
                        address: doctorWithoutPassword.email,
                        displayName: "Доктор"
                    }
                ]
            }
        };

        const poller = await emailClient.beginSend(message);
        const result = await poller.pollUntilDone();

        if (result.status === "Succeeded") {
            console.log(`Нагадування для ${doctorWithoutPassword.email} надіслано`);
        } else {
            console.warn(`Листа для ${doctorWithoutPassword.email} надіслати не вдалося`);
        }
    } catch (err) {
        console.error('Помилка при створенні лікаря:', err);
        res.status(500).send('Помилка сервера');
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Шукаємо доктора разом із його клінікою
        const doctor = await Doctor.findOne({
            where: { email },
            include: {
                model: Clinic,
                as: 'clinic', // переконайся, що асоціація визначена саме з таким alias
                attributes: ['name']
            }
        });

        if (!doctor) {
            return res.status(401).send('Невірний логін або пароль');
        }

        // Порівнюємо пароль
        const validPassword = await compare(password, doctor.password);
        if (!validPassword) {
            return res.status(401).send('Невірний логін або пароль');
        }

        // Створюємо JWT токен
        const token = jwt.sign(
            { id: doctor.id, email: doctor.email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        // Видаляємо пароль і відправляємо відповідь
        const { password: _, ...doctorData } = doctor.get({ plain: true });
        res.json({ doctor: doctorData, token });

    } catch (err) {
        console.error('Помилка при авторизації доктора:', err);
        res.status(500).send('Помилка сервера');
    }
};

const getCurrentDoctor = async (req, res) => {
    try {
        const doctor = await Doctor.findByPk(req.user.id, {
            attributes: { exclude: ['password'] } // не повертати пароль
        });

        if (!doctor) {
            return res.status(404).json({ message: 'Користувача не знайдено' });
        }

        res.json(doctor);
    } catch (err) {
        console.error('Помилка при отриманні поточного лікаря:', err);
        res.status(500).send('Помилка сервера');
    }
};

const updateDoctorProfile = async (req, res) => {
    try {
        const userId = req.user.id;
        const { name, lastname, email, phone_number, office_number } = req.body;

        const doctor = await Doctor.findByPk(userId);
        if (!doctor) {
            return res.status(404).send('Користувач не знайдений');
        }

        if (name !== undefined) doctor.name = name;
        if (lastname !== undefined) doctor.lastname = lastname;
        if (email !== undefined) doctor.email = email;
        if (phone_number !== undefined) doctor.phone_number = phone_number;
        if (office_number !== undefined) doctor.office_number = office_number;

        await doctor.save();

        const { password, ...doctorWithoutPassword } = doctor.get({ plain: true });
        res.json(doctorWithoutPassword);
    } catch (err) {
        console.error('Помилка при оновленні профілю лікаря:', err);
        res.status(500).send('Помилка сервера');
    }
};

const updateDoctorPassword = async (req, res) => {
    try {
        const userId = req.user.id;
        const { oldPassword, newPassword, confirmNewPassword } = req.body;

        if (!oldPassword || !newPassword || !confirmNewPassword) {
            return res.status(400).send('Усі поля пароля обов’язкові');
        }

        if (newPassword !== confirmNewPassword) {
            return res.status(400).send('Новий пароль і підтвердження не співпадають');
        }

        const doctor = await Doctor.findByPk(userId);
        if (!doctor) {
            return res.status(404).send('Користувача не знайдено');
        }

        const isPasswordCorrect = await compare(oldPassword, doctor.password);
        if (!isPasswordCorrect) {
            return res.status(401).send('Старий пароль неправильний');
        }

        const hashedNewPassword = await hash(newPassword, 10);
        doctor.password = hashedNewPassword;
        await doctor.save();

        res.send('Пароль успішно оновлено');
    } catch (err) {
        console.error('Помилка при зміні пароля лікаря:', err);
        res.status(500).send('Помилка сервера');
    }
};

const deleteDoctor = async (req, res) => {
    const { id } = req.params;

    try {
        const doctor = await Doctor.findByPk(id);
        if (!doctor) {
            return res.status(404).json({ message: 'Лікаря не знайдено' });
        }

        await doctor.destroy();

        res.json({ message: 'Лікаря успішно видалено' });
    } catch (err) {
        console.error('Помилка при видаленні лікаря:', err);
        res.status(500).json({ message: 'Внутрішня помилка сервера' });
    }
};

module.exports = {
    getAll,
    getById,
    update,
    create,
    login,
    getCurrentDoctor,
    updateDoctorProfile,
    updateDoctorPassword,
    deleteDoctor
};
