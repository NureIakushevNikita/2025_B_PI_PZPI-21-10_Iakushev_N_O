const { EmailClient } = require("@azure/communication-email");
const Reminder = require("../models/Reminder")
const Patient = require("../models/Patient");
const Appointment = require("../models/Appointment");
const connectionString = "endpoint=https://mycomservice21.france.communication.azure.com/;accesskey=AO5D2J0NJUgZ6xSpSdgktLNlo49ujZ8o74xlK38TS35N8bvRqAQeJQQJ99BEACULyCpJDscUAAAAAZCSFtnV";
const emailClient = new EmailClient(connectionString);

// Захардкоджені значення
const sendTestEmail = async (req, res) => {
    try {
        const message = {
            senderAddress: "DoNotReply@2152cdd7-d517-4bb8-b3e5-51a688df7fa9.azurecomm.net", // Адресу вказує Azure (дивись у ресурсі в Email Domain)
            content: {
                subject: "Нагадування про прийом",
                plainText: "Шановний користувачу! Ви записані на прийом у клініку 'Міський медичний центр №3' на 27 травня 2025 о 11:30.",
                html: "<strong>Шановний користувачу!</strong><br> Ви записані на прийом у клініку <em>'Міський медичний центр №3'</em> на <strong>27 травня 2025</strong> о <strong>11:30</strong>."
            },
            recipients: {
                to: [
                    {
                        address: "nakusev66@gmail.com", // Заміни на власну пошту
                        displayName: "Користувач"
                    }
                ]
            }
        };

        const poller = await emailClient.beginSend(message);
        const result = await poller.pollUntilDone();

        if (result.status === "Succeeded") {
            res.status(200).send("Лист успішно надіслано.");
        } else {
            res.status(500).send(`Надсилання листа не вдалося: ${result.status}`);
        }
    } catch (error) {
        console.error("Помилка надсилання листа:", error);
        res.status(500).send("Помилка сервера при відправці листа.");
    }
};

const createReminder = async (req, res) => {
    try {
        const { appointment_id, datetime } = req.body;

        if (!appointment_id || !datetime) {
            return res.status(400).json({ message: 'appointment_id і datetime є обов’язковими.' });
        }

        const reminder = await Reminder.create({
            appointment_id,
            datetime,
            status: false
        });

        res.status(201).json(reminder);
    } catch (error) {
        console.error('Помилка при створенні нагадування:', error);
        res.status(500).json({ message: 'Помилка сервера при створенні нагадування.' });
    }
};

const deleteReminder = async (req, res) => {
    try {
        const { id } = req.params;

        const reminder = await Reminder.findByPk(id);

        if (!reminder) {
            return res.status(404).json({ message: 'Нагадування не знайдено.' });
        }

        await reminder.destroy();

        res.status(200).json({ message: 'Нагадування успішно видалено.' });
    } catch (error) {
        console.error('Помилка при видаленні нагадування:', error);
        res.status(500).json({ message: 'Помилка сервера при видаленні нагадування.' });
    }
};

const getRemindersByAppointmentId = async (req, res) => {
    try {
        const { appointment_id } = req.params;

        const reminders = await Reminder.findAll({
            where: { appointment_id }
        });

        res.status(200).json(reminders);
    } catch (error) {
        console.error('Помилка при отриманні нагадувань:', error);
        res.status(500).json({ message: 'Помилка сервера при отриманні нагадувань.' });
    }
};

const getRemindersByPatientId = async (req, res) => {
    try {
        const { patient_id } = req.params;

        const reminders = await Reminder.findAll({
            include: [
                {
                    model: Appointment,
                    as: 'appointment',
                    where: { patient_id }
                }
            ]
        });

        res.status(200).json(reminders);
    } catch (error) {
        console.error('Помилка при отриманні нагадувань:', error);
        res.status(500).json({ message: 'Помилка сервера при отриманні нагадувань.' });
    }
};


module.exports = {
    sendTestEmail,
    createReminder,
    deleteReminder,
    getRemindersByAppointmentId,
    getRemindersByPatientId
};
