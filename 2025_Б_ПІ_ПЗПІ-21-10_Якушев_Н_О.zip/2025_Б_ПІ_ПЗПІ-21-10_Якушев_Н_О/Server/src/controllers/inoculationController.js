const Inoculation = require('../models/Inoculation');
const Appointment = require('../models/Appointment');
const Patient = require("../models/Patient");
const Vaccine = require('../models/Vaccine');
const Doctor = require('../models/Doctor');
const Clinic = require('../models/Clinic')
const createInoculation = async (req, res) => {
    try {
        const { appointment_id, vaccine_id } = req.body;

        const appointment = await Appointment.findByPk(appointment_id);
        if (!appointment) {
            return res.status(404).json({ message: 'Прийом не знайдено' });
        }

        const patient_id = appointment.patient_id;

        const previousInoculations = await Inoculation.findAll({
            where: {
                vaccine_id,
                status: true
            },
            include: {
                model: Appointment,
                as: 'appointment',
                where: { patient_id }
            }
        });

        const dose_number = previousInoculations.length + 1;

        const vaccine = await Vaccine.findByPk(vaccine_id);
        if (!vaccine) {
            return res.status(404).json({ message: 'Вакцину не знайдено' });
        }

        if (dose_number > vaccine.repetitions_number) {
            return res.status(400).json({ message: `Ця вакцина передбачає лише ${vaccine.repetitions_number} доз(и).` });
        }

        const inoculation = await Inoculation.create({
            appointment_id,
            vaccine_id,
            dose_number,
            status: false
        });

        res.status(201).json({ message: 'Щеплення додано успішно', inoculation });

    } catch (error) {
        console.error('Помилка при створенні щеплення:', error);
        res.status(500).json({ message: 'Внутрішня помилка сервера' });
    }
};

const updateInoculationStatus = async (req, res) => {
    try {
        const { inoculation_id, inoculation_status } = req.body;

        const inoculation = await Inoculation.findByPk(inoculation_id);
        if (!inoculation) {
            return res.status(404).json({ error: 'Щеплення не знайдено' });
        }

        inoculation.status = inoculation_status;
        await inoculation.save();

        if (inoculation_status === true) {
            const appointment = await Appointment.findByPk(inoculation.appointment_id);
            if (appointment) {
                appointment.status = 'проведено';
                await appointment.save();
            }
        }

        res.status(200).json({ message: 'Статус щеплення оновлено', inoculation });
    } catch (err) {
        console.error('Помилка при оновленні статусу щеплення:', err);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};

const getInoculationSummaryByUser = async (req, res) => {
    try {
        const user_id = req.user.id;
        const inoculations = await Inoculation.findAll({
            include: {
                model: Appointment,
                as: 'appointment',
                where: { patient_id: user_id },
                include: [
                    {
                        model: Patient,
                        as: 'patient'
                    },
                    {
                        model: Doctor,
                        as: 'doctor',
                        include: {
                            model: Clinic,
                            as: 'clinic'
                        }
                    }
                ]
            }
        });

        // Групування щеплень по вакцині
        const vaccineMap = {};

        for (const inoc of inoculations) {
            const vaccine_id = inoc.vaccine_id;
            if (!vaccineMap[vaccine_id]) {
                vaccineMap[vaccine_id] = {
                    vaccine_id,
                    current_doses: 0,
                    appointments: [],
                    patient_info: null,
                    doctor_info: null,
                    clinic_info: null
                };
            }

            vaccineMap[vaccine_id].current_doses++;
            vaccineMap[vaccine_id].appointments.push({
                inoculation_id: inoc.id,
                appointment_datetime: inoc.appointment.datetime,
                status: inoc.status,
                dose_number: inoc.dose_number
            });

            // Додаємо лише один раз загальні дані
            if (!vaccineMap[vaccine_id].patient_info) {
                const p = inoc.appointment.patient;
                vaccineMap[vaccine_id].patient_info = {
                    name: p.name,
                    lastname: p.lastname,
                    birthday: p.birthday
                };
            }

            if (!vaccineMap[vaccine_id].doctor_info) {
                const d = inoc.appointment.doctor;
                vaccineMap[vaccine_id].doctor_info = {
                    name: d.name,
                    lastname: d.lastname
                };
            }

            if (!vaccineMap[vaccine_id].clinic_info) {
                const c = inoc.appointment.doctor.clinic;
                vaccineMap[vaccine_id].clinic_info = {
                    name: c.name,
                    city: c.city,
                    address: c.address
                };
            }
        }

        // Отримуємо необхідну кількість доз для кожної вакцини
        const response = [];
        for (const vaccine_id in vaccineMap) {
            const vaccine = await Vaccine.findByPk(vaccine_id);

            const { current_doses } = vaccineMap[vaccine_id];
            const necessary_doses = vaccine.repetitions_number;
            const message =
                current_doses >= necessary_doses
                    ? 'Ви вже зробили усі необхідні щеплення для даної вакцини.'
                    : `Вам ще необхідно зробити ${necessary_doses - current_doses} щеплень даної вакцини.`;

            const message1 =
                current_doses >= necessary_doses
                    ? `Вакцинація повна. Виконано ${current_doses} щеплень з ${necessary_doses}.`
                    : `Увага! Вакцинація не завершена. Виконано ${current_doses} щеплень з ${necessary_doses}.`;

            response.push({
                vaccine_id: vaccine.id,
                vaccine_name: vaccine.name,
                current_doses,
                necessary_doses,
                message,
                message1,
                patient: vaccineMap[vaccine_id].patient_info,
                doctor: vaccineMap[vaccine_id].doctor_info,
                clinic: vaccineMap[vaccine_id].clinic_info,
                appointments: vaccineMap[vaccine_id].appointments
            });
        }

        res.status(200).json(response);
    } catch (err) {
        console.error('Помилка при отриманні щеплень користувача:', err);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};


module.exports = {
    createInoculation,
    updateInoculationStatus,
    getInoculationSummaryByUser
};
