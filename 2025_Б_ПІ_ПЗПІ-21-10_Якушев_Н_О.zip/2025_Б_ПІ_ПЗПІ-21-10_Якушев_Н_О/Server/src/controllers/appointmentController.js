const Appointment = require('../models/Appointment');
const Patient = require("../models/Patient");
const Doctor = require('../models/Doctor');
const Clinic = require('../models/Clinic')
const Vaccine = require('../models/Vaccine')
const Inoculation = require('../models/Inoculation')
const moment = require("moment");
const { Op, literal} = require('sequelize');
const { fn, col, where } = require('sequelize');
const jwt = require("jsonwebtoken");


const getAll = async (req, res) => {
    try {
        const appointments = await Appointment.findAll({
            include: [
                {
                    model: Patient,
                    as: 'patient'
                },
                {
                    model: Doctor,
                    as: 'doctor',
                    attributes: { exclude: ['password'] },
                }
            ]
        });
        res.json(appointments);
    } catch (err) {
        console.error('Помилка при отриманні прийомів:', err);
        res.status(500).send('Помилка сервера');
    }
};

const create = async (req, res) => {
    try {
        const { patient_id, doctor_id, datetime } = req.body;

        const newAppointment = await Appointment.create({
            patient_id,
            doctor_id,
            datetime,
            status: 'заплановано'
        });

        // Reload з include після створення
        const fullAppointment = await newAppointment.reload({
            include: [
                { model: Patient, as: 'patient' },
                {
                    model: Doctor,
                    as: 'doctor',
                    include: { model: Clinic, as: 'clinic' }
                }
            ]
        });

        res.status(201).json(fullAppointment);
    } catch (err) {
        console.error('Помилка при створенні прийому:', err);
        res.status(500).send('Помилка сервера');
    }
};

const getAvailableDates = async (req, res) => {
    const { clinic_id } = req.query;

    try {
        const doctors = await Doctor.findAll({ where: { clinic_id: clinic_id } });
        if (!doctors.length) {
            return res.status(200).json([]);
        }

        const doctorIds = doctors.map(d => d.id);
        const doctorMap = doctors.reduce((acc, d) => {
            acc[d.id] = d;
            return acc;
        }, {});

        const availableDates = [];
        let dateCursor = moment().startOf('day').add(1, 'day');

        while (dateCursor.isoWeekday() > 5) {
            dateCursor.add(1, 'day');
        }

        while (availableDates.length < 5) {
            const startOfDay = dateCursor.clone().hour(9).minute(0).second(0).toDate();
            const endOfDay = dateCursor.clone().hour(15).minute(0).second(0).toDate();

            const appointments = await Appointment.findAll({
                where: {
                    doctor_id: { [Op.in]: doctorIds },
                    datetime: { [Op.between]: [startOfDay, endOfDay] },
                    status: 'заплановано'
                }
            });

            const slotsPerDoctor = {};
            doctors.forEach(d => slotsPerDoctor[d.id] = new Set());

            appointments.forEach(appt => {
                const doctorId = appt.doctor_id;
                const time = moment(appt.datetime).format('HH:mm');
                slotsPerDoctor[doctorId].add(time);
            });

            const allSlots = [];
            for (let hour = 9; hour < 15; hour++) {
                allSlots.push(`${hour.toString().padStart(2, '0')}:00`);
                allSlots.push(`${hour.toString().padStart(2, '0')}:30`);
            }

            const availableDoctors = [];

            for (const doctorId of doctorIds) {
                const taken = slotsPerDoctor[doctorId];
                if (taken.size < allSlots.length) {
                    availableDoctors.push({
                        id: doctorMap[doctorId].id,
                        full_name: doctorMap[doctorId].full_name
                    });
                }
            }

            if (availableDoctors.length > 0) {
                availableDates.push({
                    date: dateCursor.format('YYYY-MM-DD'),
                    availableDoctors
                });
            }

            dateCursor.add(1, 'day');
            while (dateCursor.isoWeekday() > 5) {
                dateCursor.add(1, 'day');
            }
        }

        res.status(200).json(availableDates);
    } catch (error) {
        console.error('Помилка при отриманні доступних дат:', error);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};


const getAvailableSlots = async (req, res) => {
    const { date, doctor_id } = req.query;

    try {
        const allSlots = [];
        const baseDate = moment.utc(date).startOf('day').hour(9);
        for (let i = 0; i <= 11; i++) {
            const slot = baseDate.clone().add(i * 30, 'minutes');
            allSlots.push(slot.format('YYYY-MM-DD HH:mm:ss'));
        }

        const appointments = await Appointment.findAll({
            where: {
                doctor_id,
                status: 'заплановано',
                [Op.and]: [
                    where(fn('CONVERT', literal('date'), col('datetime')), '=', date)
                ]
            }
        });

        const takenSlots = new Set(
            appointments.map(appt =>
                moment.utc(appt.datetime).format('YYYY-MM-DD HH:mm:ss')
            )
        );

        const availableSlots = allSlots.filter(slot => !takenSlots.has(slot));

        res.status(200).json(availableSlots);
    } catch (error) {
        console.error('Помилка при отриманні вільних слотів:', error);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};

const getByPatient = async (req, res) => {
    try {
        const patientId = req.user.id;

        const appointments = await Appointment.findAll({
            where: { patient_id: patientId },
            include: [
                {
                    model: Doctor,
                    as: 'doctor',
                    attributes: { exclude: ['password'] },
                    include: {
                        model: Clinic,
                        as: 'clinic'
                    }
                },
                {
                    model: Inoculation,
                    as: 'inoculations',
                    include: {
                        model: Vaccine,
                        as: 'vaccine'
                    }
                }
            ],
            order: [['datetime', 'DESC']]
        });

        res.status(200).json(appointments);
    } catch (err) {
        console.error('Помилка при отриманні прийомів пацієнта:', err);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};


const getByDoctor = async (req, res) => {
    try {
        const doctorId = req.user.id;
        const sortOrder = req.query.order?.toUpperCase() === 'ASC' ? 'ASC' : 'DESC'; // за замовчуванням DESC

        const appointments = await Appointment.findAll({
            where: { doctor_id: doctorId },
            include: [
                {
                    model: Inoculation,
                    as: 'inoculations',
                    include: {
                        model: Vaccine,
                        as: 'vaccine',
                        attributes: ['id', 'name', 'repetitions_number', 'description']
                    }
                },
                {
                    model: Patient,
                    as: 'patient',
                    attributes: ['id', 'name', 'lastname', 'email', 'gender', 'birthday']
                }
            ],
            order: [['datetime', sortOrder]]
        });

        res.status(200).json(appointments);
    } catch (err) {
        console.error('Помилка при отриманні прийомів лікаря:', err);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};

// controllers/appointmentController.js

const cancelAppointment = async (req, res) => {
    try {
        const { appointment_id } = req.body;

        if (!appointment_id) {
            return res.status(400).json({ error: 'Необхідно вказати appointment_id' });
        }

        const appointment = await Appointment.findByPk(appointment_id);

        if (!appointment) {
            return res.status(404).json({ error: 'Запис не знайдено' });
        }

        // Оновлюємо статус на "скасовано"
        appointment.status = 'скасовано';
        await appointment.save();

        res.status(200).json({ message: 'Запис успішно скасовано', appointment });
    } catch (err) {
        console.error('Помилка при скасуванні запису:', err);
        res.status(500).json({ error: 'Внутрішня помилка сервера' });
    }
};

const deleteAppointment = async (req, res) => {
    try {
        const appointmentId = req.params.id;

        const appointment = await Appointment.findByPk(appointmentId);

        if (!appointment) {
            return res.status(404).json({ message: 'Запис на прийом не знайдено.' });
        }

        await appointment.destroy();

        res.status(200).json({ message: 'Запис успішно видалено.' });
    } catch (error) {
        console.error('Помилка при видаленні запису:', error);
        res.status(500).json({ message: 'Помилка сервера при видаленні запису.' });
    }
};



module.exports = {
    getAll,
    create,
    getAvailableDates,
    getAvailableSlots,
    getByPatient,
    getByDoctor,
    cancelAppointment,
    deleteAppointment
};
