const { Op, fn, col, literal } = require('sequelize');
const Appointment = require('../models/Appointment');
const moment = require('moment');
const Patient = require('../models/Patient');
require('moment/locale/uk');
moment.locale('uk');

const getDoctorStatistics = async (req, res) => {
    try {
        const doctor_id = req.user?.id;
        const { type } = req.query;

        if (!doctor_id || !type) {
            return res.status(400).json({ error: 'Необхідний doctor_id і тип статистики' });
        }

        let startDate, endDate;
        let groupBy = 'day';
        const today = moment().endOf('day');

        // Додамо масив для робочих днів для типу 'day'
        let workingDays = [];

        switch (type) {
            case 'day': {
                // Збираємо 10 останніх робочих днів (включно з сьогодні)
                let current = moment().startOf('day');
                while (workingDays.length < 10) {
                    if (current.isoWeekday() <= 5) {
                        workingDays.push(current.clone());
                    }
                    current = current.subtract(1, 'day');
                }
                workingDays = workingDays.reverse(); // Зробимо хронологічно від старшого до нового
                startDate = workingDays[0].startOf('day');
                endDate = workingDays[workingDays.length - 1].endOf('day');
                break;
            }

            case 'month-now': {
                startDate = moment().startOf('month');
                endDate = today;
                break;
            }

            case 'month-last': {
                startDate = moment().subtract(1, 'month').startOf('month');
                endDate = moment().subtract(1, 'month').endOf('month');
                break;
            }

            case 'year-now': {
                startDate = moment().startOf('year');
                endDate = today;
                groupBy = 'month';
                break;
            }

            case 'year-last': {
                startDate = moment().subtract(1, 'year').startOf('year');
                endDate = moment().subtract(1, 'year').endOf('year');
                groupBy = 'month';
                break;
            }

            default:
                return res.status(400).json({ error: 'Неправильний тип статистики' });
        }

        // MSSQL форматування дати
        const dateFormat = groupBy === 'month'
            ? "FORMAT(datetime, 'yyyy-MM')"
            : "FORMAT(datetime, 'yyyy-MM-dd')";

        const results = await Appointment.findAll({
            attributes: [
                [literal(dateFormat), 'period'],
                [fn('COUNT', col('id')), 'count']
            ],
            where: {
                doctor_id,
                status: 'проведено',
                datetime: {
                    [Op.between]: [startDate.toDate(), endDate.toDate()]
                }
            },
            group: [literal(dateFormat)],
            order: [[literal(dateFormat), 'ASC']]
        });

        const rawData = results.map(r => ({
            period: r.get('period'),
            count: parseInt(r.get('count'))
        }));

        let labels = [];
        let data = [];

        if (groupBy === 'day') {
            if (type === 'day') {
                // Використовуємо робочі дні з switch
                labels = workingDays.map(d => d.format('YYYY-MM-DD'));
            } else {
                // Для інших типів з денним групуванням — беремо всі дні, але виключаємо вихідні
                const days = [];
                const dayIterator = moment(startDate);
                while (dayIterator.isSameOrBefore(endDate, 'day')) {
                    if (dayIterator.isoWeekday() <= 5) {
                        days.push(dayIterator.format('YYYY-MM-DD'));
                    }
                    dayIterator.add(1, 'day');
                }
                labels = days;
            }

            data = labels.map(d => {
                const item = rawData.find(x => x.period === d);
                return item ? item.count : 0;
            });

        } else if (groupBy === 'month') {
            const months = [];
            const monthIterator = moment(startDate);
            while (monthIterator.isSameOrBefore(endDate, 'month')) {
                months.push(monthIterator.format('YYYY-MM'));
                monthIterator.add(1, 'month');
            }

            labels = months.map(m => moment(m, 'YYYY-MM').format('MMMM'));
            data = months.map(m => {
                const item = rawData.find(x => x.period === m);
                return item ? item.count : 0;
            });
        }

        return res.json({ labels, data });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Помилка при отриманні статистики' });
    }
};

const getPatientRegistrationStats = async (req, res) => {
    try {
        const { type } = req.query;

        if (!type) {
            return res.status(400).json({ error: 'Необхідно вказати тип статистики' });
        }

        let startDate, endDate;
        let groupBy = 'day';
        const today = moment().endOf('day');

        switch (type) {
            case 'day':
                startDate = moment().subtract(9, 'days').startOf('day'); // включно з сьогодні
                endDate = today;
                break;
            case 'month-now':
                startDate = moment().startOf('month');
                endDate = today;
                break;
            case 'month-last':
                startDate = moment().subtract(1, 'month').startOf('month');
                endDate = moment().subtract(1, 'month').endOf('month');
                break;
            case 'year-now':
                startDate = moment().startOf('year');
                endDate = today;
                groupBy = 'month';
                break;
            case 'year-last':
                startDate = moment().subtract(1, 'year').startOf('year');
                endDate = moment().subtract(1, 'year').endOf('year');
                groupBy = 'month';
                break;
            default:
                return res.status(400).json({ error: 'Неправильний тип статистики' });
        }

        const dateFormat = groupBy === 'month'
            ? "FORMAT(registration_date, 'yyyy-MM')"
            : "FORMAT(registration_date, 'yyyy-MM-dd')";

        const results = await Patient.findAll({
            attributes: [
                [literal(dateFormat), 'period'],
                [fn('COUNT', col('id')), 'count']
            ],
            where: {
                registration_date: {
                    [Op.between]: [startDate.toDate(), endDate.toDate()]
                }
            },
            group: [literal(dateFormat)],
            order: [[literal(dateFormat), 'ASC']]
        });

        const rawData = results.map(r => ({
            period: r.get('period'),
            count: parseInt(r.get('count'))
        }));

        // Генеруємо мітки та дані
        const labels = [];
        const data = [];

        if (groupBy === 'day') {
            const iterator = moment(startDate);
            while (iterator.isSameOrBefore(endDate, 'day')) {
                const dateStr = iterator.format('YYYY-MM-DD');
                labels.push(dateStr);
                const item = rawData.find(x => x.period === dateStr);
                data.push(item ? item.count : 0);
                iterator.add(1, 'day');
            }
        } else {
            const iterator = moment(startDate);
            while (iterator.isSameOrBefore(endDate, 'month')) {
                const monthStr = iterator.format('YYYY-MM');
                labels.push(iterator.format('MMMM'));
                const item = rawData.find(x => x.period === monthStr);
                data.push(item ? item.count : 0);
                iterator.add(1, 'month');
            }
        }

        return res.json({ labels, data });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Помилка при отриманні статистики реєстрацій' });
    }
};



module.exports = { getDoctorStatistics, getPatientRegistrationStats };
