const Patient = require('../models/Patient');
const {hash, compare} = require("bcrypt");
const jwt = require("jsonwebtoken");


// Отримати всіх пацієнтів
const getAll = async (req, res) => {
    try {
        const patients = await Patient.findAll();
        res.json(patients);
    } catch (err) {
        console.error('Помилка при отриманні пацієнтів:', err);
        res.status(500).send('Помилка сервера');
    }
};

const create = async (req, res) => {
    try {
        const { email, password, ...otherData } = req.body;

        // Перевірка наявності пацієнта з такою поштою
        const existing = await Patient.findOne({ where: { email } });
        if (existing) {
            return res.status(400).send('Користувач з такою електронною поштою вже існує');
        }

        // Хешування пароля
        const hashedPassword = await hash(password, 10);

        // Створення пацієнта
        const newPatient = await Patient.create({
            ...otherData,
            email,
            password: hashedPassword
        });

        // Не повертати пароль у відповіді
        const { password: _, ...patientWithoutPassword } = newPatient.get({ plain: true });
        res.status(201).json(patientWithoutPassword);
    } catch (err) {
        console.error('Помилка при створенні пацієнта:', err);
        res.status(500).send('Помилка сервера');
    }
};

const login = async (req, res) => {
    try {
        console.log(req.body);
        const { email, password } = req.body;
        console.log(req.body);
        // Знаходимо пацієнта за email
        const patient = await Patient.findOne({ where: { email } });
        if (!patient) {
            return res.status(401).send('Невірний логін або пароль');
        }

        // Порівнюємо пароль
        const validPassword = await compare(password, patient.password);
        if (!validPassword) {
            return res.status(401).send('Невірний логін або пароль');
        }

        // Якщо треба, створюємо JWT токен
        const token = jwt.sign(
            { id: patient.id, email: patient.email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        const { password: _, ...patientData } = patient.get({ plain: true });
        res.json({ patient: patientData, token });
    } catch (err) {
        console.error('Помилка при авторизації пацієнта:', err);
        res.status(500).send('Помилка сервера');
    }
};

const getCurrent = async (req, res) => {
    try {
        const patient = await Patient.findByPk(req.user.id, {
            attributes: { exclude: ['password'] } // не повертати пароль
        });

        if (!patient) {
            return res.status(404).json({ message: 'Користувача не знайдено' });
        }

        res.json(patient);
    } catch (err) {
        console.error('Помилка при отриманні поточного пацієнта:', err);
        res.status(500).send('Помилка сервера');
    }
};

const updateProfile = async (req, res) => {
    try {
        const userId = req.user.id; // id з токена (припускаємо, що middleware розшифровує токен і ставить req.user)
        const { name, lastname, email, phone_number, birthday, gender } = req.body;

        // Знаходимо пацієнта
        const patient = await Patient.findByPk(userId);
        if (!patient) {
            return res.status(404).send('Користувач не знайдений');
        }

        // Оновлюємо поля, якщо вони передані
        if (name !== undefined) patient.name = name;
        if (lastname !== undefined) patient.lastname = lastname;
        if (email !== undefined) patient.email = email;
        if (phone_number !== undefined) patient.phone_number = phone_number;
        if (birthday !== undefined) patient.birthday = birthday;
        if (gender !== undefined) patient.gender = gender;

        await patient.save();

        const { password, ...patientWithoutPassword } = patient.get({ plain: true });
        res.json(patientWithoutPassword);
    } catch (err) {
        console.error('Помилка при оновленні профілю:', err);
        res.status(500).send('Помилка сервера');
    }
};

const updatePassword = async (req, res) => {
    try {
        const userId = req.user.id;
        const { oldPassword, newPassword, confirmNewPassword } = req.body;

        if (!oldPassword || !newPassword || !confirmNewPassword) {
            return res.status(400).send('Всі поля (старий пароль, новий пароль, підтвердження нового пароля) обов’язкові');
        }

        if (newPassword !== confirmNewPassword) {
            return res.status(400).send('Новий пароль і підтвердження не співпадають');
        }

        const patient = await Patient.findByPk(userId);
        if (!patient) {
            return res.status(404).send('Користувач не знайдений');
        }

        // Перевіряємо старий пароль
        const validOldPassword = await compare(oldPassword, patient.password);
        if (!validOldPassword) {
            return res.status(401).send('Старий пароль неправильний');
        }

        // Хешуємо новий пароль
        const hashedNewPassword = await hash(newPassword, 10);
        patient.password = hashedNewPassword;
        await patient.save();

        res.send('Пароль успішно оновлено');
    } catch (err) {
        console.error('Помилка при оновленні пароля:', err);
        res.status(500).send('Помилка сервера');
    }
};

const removeById = async (req, res) => {
    try {
        const { id } = req.params;

        const patient = await Patient.findByPk(id);
        if (!patient) {
            return res.status(404).send('Користувача не знайдено');
        }

        await patient.destroy();
        res.sendStatus(204); // No Content
    } catch (err) {
        console.error('Помилка при видаленні пацієнта:', err);
        res.status(500).send('Помилка сервера');
    }
};

module.exports = {
    getAll,
    create,
    login,
    getCurrent,
    updateProfile,
    updatePassword,
    removeById
};
