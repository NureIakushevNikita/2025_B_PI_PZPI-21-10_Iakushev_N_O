const Vaccine = require('../models/Vaccine');

// Отримати всі вакцини
const getAll = async (req, res) => {
    try {
        const vaccines = await Vaccine.findAll();
        res.json(vaccines);
    } catch (err) {
        console.error('Помилка при отриманні вакцин:', err);
        res.status(500).send('Помилка сервера');
    }
};

// Отримати вакцину за ID
const getById = async (req, res) => {
    try {
        const vaccine = await Vaccine.findByPk(req.params.id);
        if (!vaccine) {
            return res.status(404).send('Вакцину не знайдено');
        }
        res.json(vaccine);
    } catch (err) {
        console.error('Помилка при пошуку вакцини:', err);
        res.status(500).send('Помилка сервера');
    }
};

// Створити нову вакцину
const create = async (req, res) => {
    try {
        const { name, repetitions_number, description } = req.body;

        const newVaccine = await Vaccine.create({
            name,
            repetitions_number,
            description
        });

        res.status(201).json(newVaccine);
    } catch (err) {
        console.error('Помилка при створенні вакцини:', err);
        res.status(500).send('Помилка сервера');
    }
};

const update = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, repetitions_number, description } = req.body;

        const vaccine = await Vaccine.findByPk(id);
        if (!vaccine) {
            return res.status(404).send('Вакцину не знайдено');
        }

        await vaccine.update({
            name: name ?? vaccine.name,
            repetitions_number: repetitions_number ?? vaccine.repetitions_number,
            description: description ?? vaccine.description
        });

        res.json(vaccine);
    } catch (err) {
        console.error('Помилка при оновленні вакцини:', err);
        res.status(500).send('Помилка сервера');
    }
};

// Видалити вакцину
const remove = async (req, res) => {
    try {
        const { id } = req.params;

        const vaccine = await Vaccine.findByPk(id);
        if (!vaccine) {
            return res.status(404).send('Вакцину не знайдено');
        }

        await vaccine.destroy();
        res.sendStatus(204);
    } catch (err) {
        console.error('Помилка при видаленні вакцини:', err);
        res.status(500).send('Помилка сервера');
    }
};

module.exports = {
    getAll,
    getById,
    create,
    update,
    remove
};
