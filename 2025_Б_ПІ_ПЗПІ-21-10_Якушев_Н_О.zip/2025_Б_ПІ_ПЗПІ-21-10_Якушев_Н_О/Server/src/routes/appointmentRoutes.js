const express = require('express');
const router = express.Router();
const appointmentController = require('../controllers/appointmentController');
const authenticateToken = require("../utils/authMiddleware");

router.get('/', appointmentController.getAll);
router.post('/', appointmentController.create);
router.get('/get-dates', appointmentController.getAvailableDates);
router.get('/get-slots', appointmentController.getAvailableSlots);
router.get('/my', authenticateToken, appointmentController.getByPatient);
router.get('/by-doctor', authenticateToken, appointmentController.getByDoctor);
router.patch('/cancel', appointmentController.cancelAppointment);
router.delete('/:id', appointmentController.deleteAppointment);


module.exports = router;
