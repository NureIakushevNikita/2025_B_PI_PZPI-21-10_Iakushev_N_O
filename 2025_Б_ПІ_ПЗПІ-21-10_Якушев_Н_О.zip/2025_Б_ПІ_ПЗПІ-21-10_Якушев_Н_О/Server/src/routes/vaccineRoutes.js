const express = require('express');
const router = express.Router();
const vaccinationController = require('../controllers/vaccineController');

router.get('/', vaccinationController.getAll);
router.get('/:id', vaccinationController.getById);
router.post('/', vaccinationController.create);
router.patch('/:id', vaccinationController.update);
router.delete('/:id', vaccinationController.remove);

module.exports = router;
