const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctorController');
const authenticateToken = require("../utils/authMiddleware");

router.get('/', doctorController.getAll);
router.get('/me', authenticateToken, doctorController.getCurrentDoctor);
router.patch('/me', authenticateToken, doctorController.updateDoctorProfile);
router.patch('/me/password', authenticateToken, doctorController.updateDoctorPassword);
router.get('/:id', doctorController.getById);
router.post('/', doctorController.create);
router.patch('/:id', doctorController.update);
router.post('/login', doctorController.login);
router.delete('/:id', doctorController.deleteDoctor);



module.exports = router;
