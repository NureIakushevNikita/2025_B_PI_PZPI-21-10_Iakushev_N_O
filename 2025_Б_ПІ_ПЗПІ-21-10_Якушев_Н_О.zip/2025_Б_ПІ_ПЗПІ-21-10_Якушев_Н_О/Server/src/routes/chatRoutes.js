const express = require("express");
const router = express.Router();
const { askChat } = require("../controllers/chatController");

router.post("/", askChat);

module.exports = router;
