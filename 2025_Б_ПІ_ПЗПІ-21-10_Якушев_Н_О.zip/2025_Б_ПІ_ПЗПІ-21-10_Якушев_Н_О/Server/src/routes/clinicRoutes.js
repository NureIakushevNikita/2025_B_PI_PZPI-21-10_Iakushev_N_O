const express = require('express');
const router = express.Router();
const clinicController = require('../controllers/clinicController');

router.get('/', clinicController.getAll);
router.get('/by-city', clinicController.getByCity);
router.get('/:id', clinicController.getById);
router.post('/', clinicController.create);
router.patch('/:id', clinicController.update);
router.delete('/:id', clinicController.remove);


module.exports = router;
