const express = require('express');
const router = express.Router();
const patientController = require('../controllers/PatientController');
const authenticateToken = require("../utils/authMiddleware");

router.get('/', patientController.getAll);
router.post('/', patientController.create);
router.post('/login', patientController.login);
router.get('/me', authenticateToken, patientController.getCurrent);
router.patch("/me", authenticateToken, patientController.updateProfile); // оновлення профілю
router.patch("/me/password", authenticateToken, patientController.updatePassword); // зміна пароля
router.delete('/:id', patientController.removeById);

module.exports = router;
