const express = require('express');
const router = express.Router();
const inoculationController = require('../controllers/inoculationController');
const authenticateToken = require("../utils/authMiddleware");

router.get('/', authenticateToken, inoculationController.getInoculationSummaryByUser);
router.post('/', inoculationController.createInoculation);
router.patch('/update-status', inoculationController.updateInoculationStatus);

module.exports = router;
