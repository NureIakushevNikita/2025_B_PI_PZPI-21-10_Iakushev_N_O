const express = require('express');
const router = express.Router();
const statisticController = require('../controllers/statisticsController');
const authenticateToken = require('../utils/authMiddleware');

router.get('/doctor', authenticateToken, statisticController.getDoctorStatistics);
router.get('/admin', statisticController.getPatientRegistrationStats);


module.exports = router;
