const express = require('express');
const router = express.Router();
const certificateRoutes = require('../controllers/certificateController');
const authenticateToken = require('../utils/authMiddleware');

router.post('/', certificateRoutes.generateCertificate);

module.exports = router;
