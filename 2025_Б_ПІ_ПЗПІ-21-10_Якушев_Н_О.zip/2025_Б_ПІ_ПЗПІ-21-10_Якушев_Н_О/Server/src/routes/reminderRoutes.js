const express = require('express');
const reminderController = require("../controllers/reminderController");
const router = express.Router();

router.get('/send-test', reminderController.sendTestEmail);
router.get('/by-appointment/:appointment_id', reminderController.getRemindersByAppointmentId);
router.get('/by-patient/:patient_id', reminderController.getRemindersByPatientId);
router.post('/', reminderController.createReminder);
router.delete('/:id', reminderController.deleteReminder);


module.exports = router;
