const { DataTypes, Model } = require('sequelize');
const sequelize = require('../utils/db');

class Inoculation extends Model {}

Inoculation.init({
    id: { type:
        DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    appointment_id: {
        type: DataTypes.INTEGER
    },
    vaccine_id: {
        type: DataTypes.INTEGER
    },
    dose_number: {
        type: DataTypes.INTEGER
    },
    status: {
        type: DataTypes.BOOLEAN
    }
}, {
    sequelize,
    modelName: 'Inoculation',
    tableName: 'Inoculation',
    timestamps: false
});

module.exports = Inoculation;
