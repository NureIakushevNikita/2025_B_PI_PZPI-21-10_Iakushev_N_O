const { DataTypes, Model } = require('sequelize');
const sequelize = require('../utils/db');

class Doctor extends Model {}

Doctor.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
    },
    lastname: {
        type: DataTypes.STRING,
    },
    email: {
        type: DataTypes.STRING,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
    },
    phone_number: {
        type: DataTypes.STRING
    },
    office_number: {
        type: DataTypes.INTEGER,
    },
    clinic_id: {
        type: DataTypes.INTEGER,
    },
    registration_date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    }
}, {
    sequelize,
    modelName: 'Doctor',
    tableName: 'Doctor',
    timestamps: false
});



module.exports = Doctor;
