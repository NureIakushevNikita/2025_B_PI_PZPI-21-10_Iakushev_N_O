const { DataTypes, Model } = require('sequelize');
const sequelize = require('../utils/db');

class Clinic extends Model {}

Clinic.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING
    },
    city: {
        type: DataTypes.STRING
    },
    address: {
        type: DataTypes.STRING
    },
    description: {
        type: DataTypes.STRING
    }
}, {
    sequelize,
    modelName: 'Clinic',
    tableName: 'Clinic',
    timestamps: false
});

module.exports = Clinic;
