// models/index.js
const Appointment = require('./Appointment');
const Patient = require('./Patient');
const Doctor = require('./Doctor');
const Admin = require('./Admin');
const Clinic = require('./Clinic');
const Vaccine = require('./Vaccine');
const Inoculation = require('./Inoculation');
const Reminder = require('./Reminder');

// --- Patient & Appointment ---
Patient.hasMany(Appointment, {
    foreignKey: 'patient_id',
    as: 'appointments'
});
Appointment.belongsTo(Patient, {
    foreignKey: 'patient_id',
    as: 'patient'
});

// --- Doctor & Appointment ---
Doctor.hasMany(Appointment, {
    foreignKey: 'doctor_id',
    as: 'appointments'
});
Appointment.belongsTo(Doctor, {
    foreignKey: 'doctor_id',
    as: 'doctor'
});

// --- Clinic & Doctor ---
Clinic.hasMany(Doctor, {
    foreignKey: 'clinic_id',
    as: 'doctors'
});
Doctor.belongsTo(Clinic, {
    foreignKey: 'clinic_id',
    as: 'clinic'
});

// --- Appointment & Inoculation ---
Appointment.hasMany(Inoculation, {
    foreignKey: 'appointment_id',
    as: 'inoculations'
});
Inoculation.belongsTo(Appointment, {
    foreignKey: 'appointment_id',
    as: 'appointment'
});

// --- Vaccine & Inoculation ---
Vaccine.hasMany(Inoculation, {
    foreignKey: 'vaccine_id',
    as: 'inoculations'
});
Inoculation.belongsTo(Vaccine, {
    foreignKey: 'vaccine_id',
    as: 'vaccine'
});

// --- Appointment & Reminder ---
Appointment.hasMany(Reminder, {
    foreignKey: 'appointment_id',
    as: 'reminders'
});
Reminder.belongsTo(Appointment, {
    foreignKey: 'appointment_id',
    as: 'appointment'
});

module.exports = {
    Appointment,
    Patient,
    Doctor,
    Admin,
    Clinic,
    Vaccine,
    Inoculation,
    Reminder
};
