const { DataTypes, Model } = require('sequelize');
const sequelize = require('../utils/db');

class Reminder extends Model {}

Reminder.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    appointment_id: {
        type: DataTypes.INTEGER
    },
    datetime: {
        type: DataTypes.DATE
    },
    status: {
        type: DataTypes.BOOLEAN
    }
}, {
    sequelize,
    modelName: 'Reminder',
    tableName: 'Reminder',
    timestamps: false
});

module.exports = Reminder;
