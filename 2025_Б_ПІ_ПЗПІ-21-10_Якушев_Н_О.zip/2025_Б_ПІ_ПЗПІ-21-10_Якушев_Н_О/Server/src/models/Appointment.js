const { DataTypes, Model } = require('sequelize');
const sequelize = require('../utils/db');

class Appointment extends Model {}

Appointment.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    patient_id: {
        type: DataTypes.INTEGER,
    },
    doctor_id: {
        type: DataTypes.INTEGER,
    },
    datetime: {
        type: DataTypes.DATE,
    },
    status: {
        type: DataTypes.STRING,
        validate: {
            isIn: [['заплановано', 'скасовано', 'проведено']]
        }
    }
}, {
    sequelize,
    modelName: 'Appointment',
    tableName: 'Appointment',
    timestamps: false
});

module.exports = Appointment;
