const { DataTypes, Model } = require('sequelize');
const sequelize = require('../utils/db');

class Vaccine extends Model {}

Vaccine.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING
    },
    repetitions_number: {
        type: DataTypes.INTEGER
    },
    description: { type: DataTypes.STRING }
}, {
    sequelize,
    modelName: 'Vaccine',
    tableName: 'Vaccine',
    timestamps: false
});

module.exports = Vaccine;
