// jobs/reminderJob.js
const cron = require('node-cron');
const Reminder = require('../models/Reminder');
const Clinic = require('../models/Clinic');
const Doctor = require('../models/Doctor');
const Appointment = require('../models/Appointment');
const {EmailClient} = require("@azure/communication-email");
const connectionString = process.env.AZURE_COM_SERVICE_CONN_STR;
const emailClient = new EmailClient(connectionString);
const { Op } = require('sequelize');
const Patient = require("../models/Patient");

const sendReminderEmail = async (reminder) => {
    try {
        const appointment = await Appointment.findByPk(reminder.appointment_id, {
            include: [
                {
                    model: Doctor,
                    as: 'doctor',
                    include: {
                        model: Clinic,
                        as: 'clinic'
                    }
                },
                {
                    model: Patient,
                    as: 'patient'
                }
            ]
        });

        if (!appointment) return;

        const { datetime, doctor, patient } = appointment;
        const { clinic } = doctor;
        console.log(patient)
        const subject = `Нагадування про прийом`;
        const htmlContent = `
            <strong>Шановний користувачу!</strong><br>
            Ви записані на прийом до <strong>${doctor.name} ${doctor.lastname}</strong><br>
            Клініка: <em>${clinic.name}</em><br>
            Адреса: ${clinic.city}, ${clinic.address}<br>
            Дата і час: <strong>${new Date(new Date(datetime).getTime() - 3 * 60 * 60 * 1000).toLocaleString('uk-UA')}</strong>
        `;

        const message = {
            senderAddress: "DoNotReply@2152cdd7-d517-4bb8-b3e5-51a688df7fa9.azurecomm.net",
            content: {
                subject,
                html: htmlContent,
                plainText: `Ви записані на прийом до ${doctor.name} ${doctor.lastname} у клініку ${clinic.name} на ${new Date(new Date(datetime).getTime() - 3 * 60 * 60 * 1000).toLocaleString('uk-UA')}.`
            },
            recipients: {
                to: [
                    {
                        address: patient.email,
                        displayName: "Користувач"
                    }
                ]
            }
        };

        const poller = await emailClient.beginSend(message);
        const result = await poller.pollUntilDone();

        if (result.status === "Succeeded") {
            await reminder.update({ status: true });
            console.log(`Нагадування для ${patient.email} надіслано`);
        } else {
            console.warn(`Нагадування для ${patient.email} не вдалося`);
        }

    } catch (err) {
        console.error("Помилка під час надсилання нагадування:", err);
    }
};

// Щохвилини перевіряємо, чи є листи для відправки
cron.schedule('* * * * *', async () => {
    const now = new Date();
    now.setHours(now.getHours() + 3);
    const reminders = await Reminder.findAll({
        where: {
            datetime: {
                [Op.lte]: now
            },
            status: false
        }
    });

    for (const reminder of reminders) {
        await sendReminderEmail(reminder);
    }
});
