const express = require('express');
const cors = require('cors');
require('dotenv').config();
require('./models/associations');
require('./utils/reminderJob');

const sequelize = require('./utils/db');

const patientRoutes = require('./routes/patientRoutes');
const appointmentRoutes = require('./routes/appointmentRoutes');
const doctorRoutes = require('./routes/doctorRoutes');
const clinicRoutes = require('./routes/clinicRoutes');
const vaccineRoutes = require('./routes/vaccineRoutes');
const reminderRoutes = require('./routes/reminderRoutes');
const inoculationRoutes = require('./routes/inoculationRoutes');
const  chatRoutes = require('./routes/chatRoutes');
const  certificateRoutes = require('./routes/certificateRoutes');
const  statisticsRoutes = require('./routes/statisticsRoutes');
const  adminRoutes = require('./routes/adminRoutes');


const app = express();
const allowedOrigins = [
    'http://localhost:3000',
    'https://vacclient-b6hehzg0dgadgrb7.canadacentral-01.azurewebsites.net'
];

const corsOptions = {
    origin: function (origin, callback) {
        // Разрешаем запросы без origin (например, curl или Postman)
        if (!origin) return callback(null, true);
        if (allowedOrigins.includes(origin)) {
            return callback(null, true);
        } else {
            return callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
};

app.use(cors(corsOptions));

app.use(express.json());

const PORT = process.env.PORT || 5000;

app.get('/', (req, res) => {
    res.send('Сервер працює');
});


(async () => {
    try {
        await sequelize.authenticate();
        console.log('З’єднання з базою успішне!');
        // await sequelize.sync();
    } catch (err) {
        console.error('Помилка з’єднання з базою:', err);
    }
})();

app.use('/patients', patientRoutes);

app.use('/appointments', appointmentRoutes);

app.use('/doctors', doctorRoutes);

app.use('/clinics', clinicRoutes);

app.use('/vaccines', vaccineRoutes);

app.use('/reminders', reminderRoutes);

app.use('/inoculations', inoculationRoutes);

app.use('/chat', chatRoutes);

app.use('/certificate', certificateRoutes);

app.use('/statistics', statisticsRoutes);

app.use('/admin', adminRoutes);


app.listen(PORT, () => {
    console.log(`Сервер запущено на порту ${PORT}`);
});
