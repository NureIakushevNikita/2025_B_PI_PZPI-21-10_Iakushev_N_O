import React, { useState } from 'react';
import '../styles/addClinicModal.css';

const AddVaccineModal = ({ onClose, onVaccineAdded }) => {
    const [form, setForm] = useState({
        name: '',
        repetitions_number: '',
        description: ''
    });

    const handleChange = (field, value) => {
        setForm(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = async () => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/vaccines`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(form)
            });

            if (!res.ok) throw new Error('Помилка при створенні вакцини');
            const created = await res.json();
            onVaccineAdded(created);
            onClose();
        } catch (err) {
            alert(err.message);
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal">
                <h3>Додати нову вакцину</h3>
                <input
                    type="text"
                    placeholder="Назва"
                    value={form.name}
                    onChange={e => handleChange('name', e.target.value)}
                />
                <input
                    type="number"
                    placeholder="Кількість доз"
                    value={form.repetitions_number}
                    onChange={e => handleChange('repetitions_number', parseInt(e.target.value))}
                />
                <textarea
                    placeholder="Опис"
                    value={form.description}
                    onChange={e => handleChange('description', e.target.value)}
                />
                <div className="modal-buttons">
                    <button className="cancel-btn" onClick={onClose}>Скасувати</button>
                    <button className="save-btn" onClick={handleSubmit}>Зберегти</button>
                </div>
            </div>
        </div>
    );
};

export default AddVaccineModal;
