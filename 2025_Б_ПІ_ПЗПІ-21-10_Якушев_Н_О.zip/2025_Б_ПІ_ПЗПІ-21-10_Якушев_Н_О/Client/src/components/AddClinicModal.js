import React, { useState } from 'react';
import '../styles/addClinicModal.css';

const AddClinicModal = ({ onClose, onClinicAdded }) => {
    const [form, setForm] = useState({
        name: '',
        city: '',
        address: '',
        description: ''
    });

    const handleChange = (field, value) => {
        setForm(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = async () => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/clinics`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(form)
            });

            if (!res.ok) throw new Error('Помилка при створенні клініки');

            const newClinic = await res.json();
            onClinicAdded(newClinic);
            onClose();
        } catch (err) {
            alert(err.message || 'Помилка при створенні клініки');
        }
    };

    return (
        <div className="modal-backdrop">
            <div className="modal">
                <h3>Додати новий медичний заклад</h3>
                <input placeholder="Назва" value={form.name} onChange={e => handleChange('name', e.target.value)} />
                <input placeholder="Місто" value={form.city} onChange={e => handleChange('city', e.target.value)} />
                <input placeholder="Адреса" value={form.address} onChange={e => handleChange('address', e.target.value)} />
                <textarea placeholder="Опис" value={form.description} onChange={e => handleChange('description', e.target.value)} />
                <div className="modal-actions">
                    <button className="cancel-btn" onClick={onClose}>Скасувати</button>
                    <button className="save-btn" onClick={handleSubmit}>Створити</button>
                </div>
            </div>
        </div>
    );
};

export default AddClinicModal;
