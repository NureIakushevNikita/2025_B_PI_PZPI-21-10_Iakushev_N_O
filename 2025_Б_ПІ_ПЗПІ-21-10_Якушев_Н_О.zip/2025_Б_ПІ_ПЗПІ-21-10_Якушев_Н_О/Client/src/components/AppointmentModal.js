import React, { useEffect, useState } from 'react';
import './../styles/appointmentModal.css';

const AppointmentModal = ({ clinicId, onClose, onConfirmSelection }) => {
    const [availableDates, setAvailableDates] = useState([]);
    const [selectedDate, setSelectedDate] = useState('');
    const [availableSlots, setAvailableSlots] = useState([]);
    const [selectedSlot, setSelectedSlot] = useState('');
    const [selectedDoctor, setSelectedDoctor] = useState(null);

    useEffect(() => {
        const fetchDates = async () => {
            try {
                const response = await fetch(`${process.env.REACT_APP_BASE_URL}/appointments/get-dates?clinic_id=${clinicId}`);
                const data = await response.json();
                setAvailableDates(data);
            } catch (err) {
                console.error('Помилка при отриманні дат:', err);
            }
        };

        fetchDates();
    }, [clinicId]);

    const handleDateChange = async (e) => {
        const date = e.target.value;
        setSelectedDate(date);
        setSelectedSlot('');
        setAvailableSlots([]);
        setSelectedDoctor(null);

        const doctor = availableDates.find((d) => d.date === date)?.availableDoctors[0];
        if (!doctor) return;

        setSelectedDoctor(doctor);

        try {
            const response = await fetch(
                `${process.env.REACT_APP_BASE_URL}/appointments/get-slots?date=${date}&doctor_id=${doctor.id}`
            );
            const data = await response.json();
            setAvailableSlots(data);
        } catch (err) {
            console.error('Помилка при отриманні слотів:', err);
        }
    };

    const handleConfirm = () => {
        if (!selectedDoctor || !selectedSlot) return;

        onConfirmSelection({
            date: selectedDate,
            time: selectedSlot,
            doctor: selectedDoctor,
        });

        onClose();
    };

    return (
        <div className="modal-overlay">
            <div className="modal-window">
                <button className="modal-close" onClick={onClose}>×</button>
                <h3>Запис на щеплення</h3>

                <label>Дата:</label>
                <select value={selectedDate} onChange={handleDateChange}>
                    <option value="">Оберіть дату</option>
                    {availableDates.map((d) => (
                        <option key={d.date} value={d.date}>{d.date}</option>
                    ))}
                </select>

                <label>Час:</label>
                <select
                    value={selectedSlot}
                    onChange={(e) => setSelectedSlot(e.target.value)}
                    disabled={availableSlots.length === 0}
                >
                    <option value="">
                        {selectedDate ? 'Оберіть час' : 'Спершу оберіть дату'}
                    </option>
                    {availableSlots.map((slot, i) => (
                        <option key={i} value={slot}>{slot.slice(11, 16)}</option>
                    ))}
                </select>

                <button onClick={handleConfirm} disabled={!selectedSlot}>Підтвердити</button>
            </div>
        </div>
    );
};

export default AppointmentModal;
