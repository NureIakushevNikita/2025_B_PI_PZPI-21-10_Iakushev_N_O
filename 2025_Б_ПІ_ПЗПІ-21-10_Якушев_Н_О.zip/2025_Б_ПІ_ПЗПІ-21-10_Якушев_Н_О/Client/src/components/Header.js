import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./../styles/header.css";

const Header = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const isAuthenticated = !!localStorage.getItem("token");

    const allowedPaths = [
        "/appointments/book",
        "/my-appointments",
        "/patient/profile",
        "/clinic-search",
        "/appointments",
        "/my-vaccines",
        "/chat",
        "/doctor/profile",
        "/doctor/appointments",
        "/doctor/statistics",
        "/doctors",
        "/vaccine",
        "/admin/statistics",
        "/clinics"
    ];

    const shouldShowBackButton =
        isAuthenticated && allowedPaths.includes(location.pathname);

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("userId");
        localStorage.removeItem("clinicName");
        localStorage.removeItem("doctorId");
        localStorage.removeItem("adminId");
        navigate("/patient/login");
    };

    return (
        <header className="header">
            <div className="header-left">
                <h1
                    className="logo"
                    onClick={() => {
                        if (isAuthenticated) {
                            navigate("/dashboard");
                        } else {
                            navigate("/");
                        }
                    }}
                >
                    VacHealth
                </h1>
                {shouldShowBackButton && (
                    <button
                        className="header-button back-button"
                        onClick={() => navigate(-1)}
                    >
                        ← Назад
                    </button>
                )}
            </div>

            <div className="header-right">
                {isAuthenticated ? (
                    <button className="header-button" onClick={handleLogout}>
                        Вийти
                    </button>
                ) : (
                    <>
                        <button
                            className="header-button"
                            onClick={() => navigate("/patient/login")}
                        >
                            Авторизація
                        </button>
                        <button
                            className="header-button"
                            onClick={() => navigate("/patient/registration")}
                        >
                            Реєстрація
                        </button>
                    </>
                )}
            </div>
        </header>
    );
};

export default Header;
