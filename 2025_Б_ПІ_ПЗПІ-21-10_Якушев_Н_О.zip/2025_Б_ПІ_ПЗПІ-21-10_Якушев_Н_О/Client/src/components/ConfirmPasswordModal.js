import React, { useState } from 'react';
import '../styles/confirmPasswordModel.css';

const ConfirmPasswordModal = ({ onConfirm, onCancel }) => {
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onConfirm(password);
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h3>Підтвердіть дію</h3>
                <form onSubmit={handleSubmit}>
                    <input
                        type="password"
                        placeholder="Введіть пароль"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <div className="modal-buttons">
                        <button type="button" className="cancel-btn" onClick={onCancel}>Скасувати</button>
                        <button type="submit" className="confirm-btn">Підтвердити</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ConfirmPasswordModal;
