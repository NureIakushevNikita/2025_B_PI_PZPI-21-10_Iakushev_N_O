import React, { useState, useEffect } from 'react';
import '../styles/addDoctorModal.css';

const AddDoctorModal = ({ onClose, onDoctorAdded }) => {
    const [formData, setFormData] = useState({
        name: '',
        lastname: '',
        email: '',
        password: '',
        phone_number: '',
        office_number: '',
        clinic_id: ''
    });

    const [clinics, setClinics] = useState([]);

    useEffect(() => {
        fetch(`${process.env.REACT_APP_BASE_URL}/clinics`)
            .then(res => res.json())
            .then(setClinics)
            .catch(err => console.error('Помилка при завантаженні клінік:', err));
    }, []);

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) throw new Error('Помилка при додаванні лікаря');

            const newDoctor = await response.json();
            onDoctorAdded(newDoctor);
            onClose();
        } catch (err) {
            console.error(err);
            alert('Не вдалося додати лікаря');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal">
                <h3>Додати нового лікаря</h3>
                <input
                    type="text"
                    placeholder="Ім’я"
                    value={formData.name}
                    onChange={e => handleChange('name', e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Прізвище"
                    value={formData.lastname}
                    onChange={e => handleChange('lastname', e.target.value)}
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={e => handleChange('email', e.target.value)}
                />
                <input
                    type="password"
                    placeholder="Пароль"
                    value={formData.password}
                    onChange={e => handleChange('password', e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Телефон"
                    value={formData.phone_number}
                    onChange={e => handleChange('phone_number', e.target.value)}
                />
                <input
                    type="number"
                    placeholder="Кабінет"
                    value={formData.office_number}
                    onChange={e => handleChange('office_number', e.target.value)}
                />
                <select
                    value={formData.clinic_id}
                    onChange={e => handleChange('clinic_id', e.target.value)}
                >
                    <option value="">Оберіть медичний заклад</option>
                    {clinics.map(clinic => (
                        <option key={clinic.id} value={clinic.id}>
                            {clinic.name} — {clinic.city}
                        </option>
                    ))}
                </select>
                <div className="modal-buttons">
                    <button className="save-btn" onClick={handleSubmit}>Зберегти</button>
                    <button className="cancel-btn" onClick={onClose}>Скасувати</button>
                </div>
            </div>
        </div>
    );
};

export default AddDoctorModal;
