import React from "react";
import { useNavigate } from "react-router-dom";
import "../styles/backButton.css";

const BackButton = ({ label = "Назад" }) => {
    const navigate = useNavigate();

    const handleClick = () => {
        navigate(-1);
    };

    return (
        <button className="back-button" onClick={handleClick}>
            ← {label}
        </button>
    );
};

export default BackButton;
