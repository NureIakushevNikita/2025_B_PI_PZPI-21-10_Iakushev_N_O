import React from 'react';
import { Route, Routes } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import RegistrationPage from "./pages/RegistrationPage";
import Header from "./components/Header"
import DashboardPage from "./pages/DashboardPage";
import PatientProfilePage from "./pages/PatientProfilePage";
import ClinicSearch from "./pages/ClinicSearch";
import {Toaster} from "react-hot-toast";
import MyAppointments from "./pages/MyAppointments";
import ChatPage from "./pages/ChatPage";
import VaccinationsPage from "./pages/VaccinationsPage";
import LoginDoctorPage from "./pages/LoginDoctorPage";
import DoctorAppointmentsPage from "./pages/DoctorAppointmentsPage";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import MyVaccinesPage from "./pages/MyVaccinesPage";
import DoctorStatisticsPage from "./pages/DoctorStatisticsPage";
import AdminLoginPage from "./pages/LoginAdminPage";
import ClinicsPage from "./pages/ClinicsPage";
import DoctorsPage from "./pages/DoctorsPage";
import VaccinePage from "./pages/VaccinePage";
import AdminStatisticsPage from "./pages/AdminStatisticsPage";
import MainPage from "./pages/MainPage";


function App() {
  return (
      <div>
          <Header/>
          <Routes>
              <Route path="/patient/login" element={<LoginPage />} />
              <Route path="/patient/registration" element={<RegistrationPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/patient/profile" element={<PatientProfilePage />} />
              <Route path="/appointments/book" element={<ClinicSearch />} />
              <Route path="/appointments" element={<MyAppointments />} />
              <Route path="/chat" element={<ChatPage />} />
              <Route path="/vaccines" element={<VaccinationsPage />} />
              <Route path="/doctor/login" element={<LoginDoctorPage />} />
              <Route path="/doctor/appointments" element={<DoctorAppointmentsPage />} />
              <Route path="/doctor/profile" element={<DoctorProfilePage />} />
              <Route path="/my-vaccines" element={<MyVaccinesPage />} />
              <Route path="/doctor/statistics" element={<DoctorStatisticsPage />} />
              <Route path="/admin/login" element={<AdminLoginPage />} />
              <Route path="/clinics" element={<ClinicsPage />} />
              <Route path="/doctors" element={<DoctorsPage />} />
              <Route path="/vaccine" element={<VaccinePage />} />
              <Route path="/admin/statistics" element={<AdminStatisticsPage />} />
              <Route path="/" element={<MainPage />} />

          </Routes>
          <Toaster
              position="top-center"
              reverseOrder={false}
          />
      </div>
  );
}

export default App;