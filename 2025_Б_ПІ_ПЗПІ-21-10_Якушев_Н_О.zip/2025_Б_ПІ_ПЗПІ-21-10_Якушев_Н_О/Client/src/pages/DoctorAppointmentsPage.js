import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/doctorAppointments.css";

const DoctorAppointmentsPage = () => {
    const [appointments, setAppointments] = useState([]);
    const [expandedId, setExpandedId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [order, setOrder] = useState("asc");

    useEffect(() => {
        const fetchAppointments = async () => {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.get(`${process.env.REACT_APP_BASE_URL}/appointments/by-doctor?order=${order}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setAppointments(response.data);
            } catch (err) {
                console.error("Помилка при завантаженні прийомів:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchAppointments();
    }, [order]);

    const toggleExpanded = (id) => {
        setExpandedId(expandedId === id ? null : id);
    };

    const markInoculationDone = async (inoculationId, appointmentId) => {
        try {
            const token = localStorage.getItem("doctorToken");
            await axios.patch(`${process.env.REACT_APP_BASE_URL}/inoculations/update-status`, {
                inoculation_id: inoculationId,
                inoculation_status: true,
            }, {
                headers: { Authorization: `Bearer ${token}` },
            });

            setAppointments(prev =>
                prev.map(app =>
                    app.id === appointmentId
                        ? {
                            ...app,
                            status: "проведено",
                            inoculations: app.inoculations.map(inoc =>
                                inoc.id === inoculationId ? { ...inoc, status: true } : inoc
                            ),
                        }
                        : app
                )
            );
        } catch (err) {
            console.error("Помилка при оновленні статусу щеплення:", err);
        }
    };

    return (
        <div className="doctor-appointments-container">
            <h2>Ваші прийоми</h2>
            <div className="sort-toggle">
                <label>Сортування:</label>
                <select value={order} onChange={(e) => setOrder(e.target.value)}>
                    <option value="asc">Від найстарішого</option>
                    <option value="desc">Від найновішого</option>
                </select>
            </div>

            {loading ? (
                <p>Завантаження...</p>
            ) : appointments.length === 0 ? (
                <p>Немає прийомів</p>
            ) : (
                <ul className="appointment-list">
                    {appointments.map(appt => (
                        <li key={appt.id} className="appointment-item">
                            <div className="appointment-summary" onClick={() => toggleExpanded(appt.id)}>
                                <div>
                                    <strong>Дата:</strong>{" "}
                                    {new Date(new Date(appt.datetime).getTime() - 3 * 60 * 60 * 1000).toLocaleString('uk-UA')}
                                </div>
                                <div><strong>Статус:</strong> {appt.status}</div>
                                {appt.inoculations.map(inoc => (
                                    <div key={inoc.id}>
                                        <strong>Вакцина:</strong> {inoc.vaccine.name} — {inoc.dose_number} доза з {inoc.vaccine.repetitions_number}
                                    </div>
                                ))}
                            </div>

                            {expandedId === appt.id && (
                                <div className="appointment-details">
                                    <p><strong>Ім’я:</strong> {appt.patient.lastname} {appt.patient.name}</p>
                                    <p><strong>Email:</strong> {appt.patient.email}</p>
                                    <p><strong>Стать:</strong> {appt.patient.gender === 'M' ? 'Чоловіча' : 'Жіноча'}</p>
                                    <p><strong>Дата народження:</strong> {new Date(appt.patient.birthday).toLocaleDateString()}</p>

                                    {appt.inoculations.map(inoc => (
                                        <button
                                            key={inoc.id}
                                            onClick={() => markInoculationDone(inoc.id, appt.id)}
                                            disabled={inoc.status}
                                            className={inoc.status ? "btn-disabled" : "btn-active"}
                                        >
                                            {inoc.status ? "Щеплення виконано" : "Підтвердити щеплення"}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default DoctorAppointmentsPage;
