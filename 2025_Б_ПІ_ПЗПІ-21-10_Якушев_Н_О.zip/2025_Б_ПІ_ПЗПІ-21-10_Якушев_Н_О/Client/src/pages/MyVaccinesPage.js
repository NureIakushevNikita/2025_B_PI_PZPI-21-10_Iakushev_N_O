import React, { useEffect, useState } from 'react';
import '../styles/myVaccinesPage.css';
import axios from "axios";
import { toast } from "react-hot-toast";

function MyVaccinesPage() {
    const [vaccines, setVaccines] = useState([]);
    const [loading, setLoading] = useState(true);
    const [loadingId, setLoadingId] = useState(null); // <-- новий стан

    const fetchVaccines = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${process.env.REACT_APP_BASE_URL}/inoculations`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setVaccines(response.data);
        } catch (err) {
            console.error('Помилка при завантаженні вакцин:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchVaccines();
    }, []);

    const generateCertificate = async (vaccine) => {
        try {
            const vaccine_id = vaccine.vaccine_id || vaccine.vaccine?.id || null;
            if (!vaccine_id) {
                toast.error("Немає інформації про вакцину для формування довідки.");
                return;
            }

            setLoadingId(vaccine_id); // старт завантаження

            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/certificate`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    vaccine_id,
                    vaccinationData: vaccines,
                }),
            });

            if (!response.ok) {
                let errorMessage = "Невідома помилка";
                try {
                    const errorData = await response.json();
                    errorMessage = errorData.message || errorMessage;
                } catch {}
                toast.error("Помилка при формуванні довідки: " + errorMessage);
                setLoadingId(null); // кінець завантаження (з помилкою)
                return;
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `certificate_${vaccine_id}.docx`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);

            toast.success("Довідку сформовано та завантажено.");
            setLoadingId(null); // кінець завантаження
        } catch (error) {
            console.error("Помилка при формуванні довідки:", error);
            toast.error("Сталася помилка при формуванні довідки.");
            setLoadingId(null); // кінець завантаження (з помилкою)
        }
    };

    return (
        <div className="my-vaccines-page">
            <h2>Мої щеплення</h2>
            {loading ? (
                <p>Завантаження...</p>
            ) : vaccines.length === 0 ? (
                <p>Даних не знайдено.</p>
            ) : (
                vaccines.map((vaccine, index) => (
                    <div className="vaccine-card" key={index}>
                        <h3>{vaccine.vaccine_name}</h3>
                        <p><strong>Кількість щеплень:</strong> {vaccine.current_doses} / {vaccine.necessary_doses}</p>
                        <p className="vaccine-message">{vaccine.message}</p>

                        <div className="info-block">
                            <p><strong>Пацієнт:</strong> {vaccine.patient.name} {vaccine.patient.lastname} ({new Date(vaccine.patient.birthday).toLocaleDateString()})</p>
                            <p><strong>Лікар:</strong> {vaccine.doctor.name} {vaccine.doctor.lastname}</p>
                            <p><strong>Клініка:</strong> {vaccine.clinic.name}, {vaccine.clinic.city}, {vaccine.clinic.address}</p>
                        </div>

                        <div className="doses-list">
                            <h4>Інформація про щеплення:</h4>
                            <ul>
                                {vaccine.appointments.map((appointment) => (
                                    <li key={appointment.inoculation_id}>
                                        <strong>{appointment.dose_number} щеплення:</strong> {new Date(new Date(appointment.appointment_datetime).getTime() - 3 * 60 * 60 * 1000).toLocaleString()}
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {loadingId === (vaccine.vaccine_id || vaccine.vaccine?.id) ? (
                            <div className="spinner"></div>  // тут спіннер
                        ) : (
                            <button
                                onClick={() => generateCertificate(vaccine)}
                                className="generate-certificate-button"
                            >
                                Сформувати електронну довідку
                            </button>
                        )}
                    </div>
                ))
            )}
        </div>
    );
}

export default MyVaccinesPage;
