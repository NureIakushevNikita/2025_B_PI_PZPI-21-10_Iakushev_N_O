import React, { useEffect, useState } from "react";
import "../styles/myAppointments.css";
import { Toaster, toast } from "react-hot-toast";


const MyAppointments = () => {
    const [appointments, setAppointments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [reminders, setReminders] = useState({}); // appointment_id: { date, time }
    const [existingReminders, setExistingReminders] = useState({}); // appointment_id: reminder object

    useEffect(() => {
        const fetchAppointments = async () => {
            try {
                const response = await fetch(`${process.env.REACT_APP_BASE_URL}/appointments/my`, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                const data = await response.json();
                setAppointments(data);

                // Після отримання записів, отримати нагадування по кожному appointment.id
                const remindersMap = {};
                for (const appt of data) {
                    const res = await fetch(`${process.env.REACT_APP_BASE_URL}/reminders/by-appointment/${appt.id}`, {
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem("token")}`,
                        },
                    });
                    if (res.ok) {
                        const reminderList = await res.json();
                        if (reminderList.length > 0) {
                            remindersMap[appt.id] = reminderList[0]; // В нас лише 1 reminder
                        }
                    }
                }
                setExistingReminders(remindersMap);
            } catch (err) {
                console.error("Помилка при завантаженні:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchAppointments();
    }, []);

    const handleReminderChange = (id, field, value) => {
        setReminders((prev) => ({
            ...prev,
            [id]: {
                ...prev[id],
                [field]: value,
            },
        }));
    };

    const handleDeleteAppointment = async (appointmentId) => {
        if (!window.confirm("Ви впевнені, що хочете скасувати цей запис?")) return;

        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/appointments/${appointmentId}`, {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });

            if (res.ok) {
                toast.success("Запис скасовано.");
                setAppointments((prev) => prev.filter((appt) => appt.id !== appointmentId));
            } else {
                const errData = await res.json();
                toast.error("Помилка при видаленні запису: " + errData.message);
            }
        } catch (err) {
            console.error("Помилка при видаленні запису:", err);
            toast.error("Не вдалося скасувати запис.");
        }
    };


    const handleSetReminder = async (appt) => {
        const reminder = reminders[appt.id];
        if (!reminder?.date || !reminder?.time) {
            toast.error("Будь ласка, заповніть дату та час.");
        }

        const reminderDateTime = new Date(`${reminder.date}T${reminder.time}`);
        const now = new Date();
        const appointmentDateTime = new Date(appt.datetime);

        if (reminderDateTime <= now) {
            toast.error("Нагадування не може бути в минулому");
            return;
        }

        if (reminderDateTime >= appointmentDateTime) {
            toast.error("Нагадування не може бути після прийому.");
            return;
        }

        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/reminders`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify({
                    appointment_id: appt.id,
                    datetime: reminderDateTime,
                }),
            });

            if (res.ok) {
                const created = await res.json();
                toast.success("Нагадування створено успішно.");
                setExistingReminders((prev) => ({
                    ...prev,
                    [appt.id]: created,
                }));
                setReminders((prev) => ({ ...prev, [appt.id]: {} }));
            } else {
                const errData = await res.json();
            }
        } catch (err) {
            toast.error("Помилка при створені нагадування");
            console.error("Помилка при створенні нагадування:", err);
        }
    };

    const handleDeleteReminder = async (reminderId, appointmentId) => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/reminders/${reminderId}`, {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });

            if (res.ok) {
                toast.success("Нагадування видалено!");
                setExistingReminders((prev) => {
                    const updated = { ...prev };
                    delete updated[appointmentId];
                    return updated;
                });
            } else {
                const errData = await res.json();
                alert("Помилка при видаленні: " + errData.message);
            }
        } catch (err) {
            console.error("Помилка при видаленні нагадування:", err);
        }
    };

    return (
        <div className="appointments-container">
            <h2>Мої записи на щеплення</h2>
            {loading ? (
                <div className="loading-spinner-container">
                    <div className="loading-spinner"></div>
                    <p className="loading-text">Завантаження...</p>
                </div>
            ) : appointments.length === 0 ? (
                <p>У вас немає жодного запису на щеплення.</p>
            ) : (
                <ul className="appointments-list">
                    {appointments.map((appt) => (
                        <li key={appt.id} className="appointment-item">
                            <h3>{appt.doctor.clinic.name}</h3>
                            <p><strong>Адреса:</strong> {appt.doctor.clinic.city}, {appt.doctor.clinic.address}</p>
                            <p><strong>Дата та час:</strong> {
                                new Date(new Date(appt.datetime).getTime() - 3 * 60 * 60 * 1000)
                                    .toLocaleString('uk-UA', {
                                        hour: '2-digit',
                                        minute: '2-digit',
                                        day: '2-digit',
                                        month: '2-digit',
                                        year: 'numeric'
                                    })
                            }</p>
                            <p><strong>Доктор:</strong> {appt.doctor.lastname} {appt.doctor.name}</p>
                            <p><strong>Кабінет:</strong> №{appt.doctor.office_number}</p>
                            <p><strong>Статус:</strong> {appt.status}</p>

                            {appt.inoculations && appt.inoculations.length > 0 && (
                                <div className="inoculation-info">
                                    {appt.inoculations.map((inoculation) => (
                                        <p key={inoculation.id}>
                                            <strong>Вакцина:</strong> {inoculation.vaccine.name} — {inoculation.dose_number} доза
                                        </p>
                                    ))}
                                </div>
                            )}
                            <button
                                className="delete-appointment-button"
                                onClick={() => handleDeleteAppointment(appt.id)}
                            >
                                Видалити запис
                            </button>
                            <div className="reminder-section">
                                <h4>Нагадування</h4>
                                {existingReminders[appt.id] ? (
                                    <div className="reminder-info">
                                        <p><strong>Заплановано:</strong> {
                                            new Date(new Date(existingReminders[appt.id].datetime).getTime() - 3 * 60 * 60 * 1000)
                                                .toLocaleString('uk-UA', {
                                                    hour: '2-digit',
                                                    minute: '2-digit',
                                                    day: '2-digit',
                                                    month: '2-digit',
                                                    year: 'numeric'
                                                })
                                        }</p>
                                        <button
                                            className="delete-reminder-button"
                                            onClick={() => handleDeleteReminder(existingReminders[appt.id].id, appt.id)}
                                        >
                                            Видалити нагадування
                                        </button>

                                    </div>
                                ) : (
                                    <div className="reminder-inputs">
                                        <input
                                            type="date"
                                            value={reminders[appt.id]?.date || ""}
                                            onChange={(e) => handleReminderChange(appt.id, "date", e.target.value)}
                                        />
                                        <input
                                            type="time"
                                            value={reminders[appt.id]?.time || ""}
                                            onChange={(e) => handleReminderChange(appt.id, "time", e.target.value)}
                                        />
                                        <button onClick={() => handleSetReminder(appt)}>Створити нагадування</button>
                                    </div>
                                )}
                            </div>
                        </li>

                    ))}
                </ul>
            )}
        </div>
    );
};

export default MyAppointments;
