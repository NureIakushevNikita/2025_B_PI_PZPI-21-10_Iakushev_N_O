import React, { useState } from "react";
import "./../styles/register.css";
import { Toaster, toast } from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const RegistrationPage = () => {
    const [formData, setFormData] = useState({
        name: "",
        lastname: "",
        email: "",
        password: "",
        confirmPassword: "",
        phone_number: "",
        birthday: "",
        gender: "",
    });
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (formData.password !== formData.confirmPassword) {
            toast.error("Паролі не співпадають");
            return;
        }

        try {
            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/patients`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    name: formData.name,
                    lastname: formData.lastname,
                    email: formData.email,
                    password: formData.password,
                    phone_number: formData.phone_number,
                    birthday: formData.birthday,
                    gender: formData.gender,
                }),
            });

            if (response.ok) {
                toast.success("Реєстрація успішна!");
                setFormData({
                    name: "",
                    lastname: "",
                    email: "",
                    password: "",
                    confirmPassword: "",
                    phone_number: "",
                    birthday: "",
                    gender: "",
                });
                setTimeout(() => {
                    window.location.href = "/patient/login";
                }, 1500);
            } else {
                const errorText = await response.text();
                toast.error(errorText);

            }
        } catch (error) {
            toast.error("Помилка сервера. Спробуйте пізніше.");
            console.error("Registration error:", error);
        }
    };

    return (
        <div className="register-container">
            <form className="register-form" onSubmit={handleSubmit}>
                <h2>Реєстрація</h2>
                <input
                    type="text"
                    name="name"
                    placeholder="Ім’я"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="lastname"
                    placeholder="Прізвище"
                    value={formData.lastname}
                    onChange={handleChange}
                    required
                />
                <input
                    type="email"
                    name="email"
                    placeholder="Електронна пошта"
                    value={formData.email}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Пароль"
                    value={formData.password}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="confirmPassword"
                    placeholder="Підтвердження пароля"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    required
                />
                <input
                    type="tel"
                    name="phone_number"
                    placeholder="Номер телефону"
                    value={formData.phone_number}
                    onChange={handleChange}
                />
                <input
                    type="date"
                    name="birthday"
                    placeholder="Дата народження"
                    value={formData.birthday}
                    onChange={handleChange}
                />
                <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    required
                >
                    <option value="">Оберіть стать</option>
                    <option value="M">Чоловіча</option>
                    <option value="F">Жіноча</option>
                </select>
                <button type="submit">Зареєструватися</button>
                <p className="login-text">
                    Вже маєте акаунт? <a href="/patient/login">Увійти</a>
                </p>
            </form>
        </div>
    );
};

export default RegistrationPage;
