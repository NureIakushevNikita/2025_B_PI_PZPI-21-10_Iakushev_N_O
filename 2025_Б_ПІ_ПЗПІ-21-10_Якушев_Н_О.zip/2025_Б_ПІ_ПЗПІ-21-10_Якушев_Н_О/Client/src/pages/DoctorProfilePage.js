import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../styles/profile.css";

const DoctorProfilePage = () => {
    const [doctor, setDoctor] = useState(null);
    const [editData, setEditData] = useState({});
    const [passwordData, setPasswordData] = useState({ oldPassword: "", newPassword: "", confirmNewPassword: "" });
    const navigate = useNavigate();

    const clinicName = localStorage.getItem("clinicName");

    useEffect(() => {
        const fetchProfile = async () => {
            const token = localStorage.getItem("token");
            if (!token) {
                navigate("/doctor/login");
                return;
            }

            try {
                const response = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors/me`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });

                if (!response.ok) throw new Error("Помилка при завантаженні профілю");

                const data = await response.json();
                setDoctor(data);
                setEditData(data);
            } catch (error) {
                console.error("Помилка:", error);
                toast.error("Не вдалося завантажити профіль");
            }
        };

        fetchProfile();
    }, [navigate]);

    const handleEditChange = (e) => {
        setEditData({ ...editData, [e.target.name]: e.target.value });
    };

    const handleSaveProfile = async () => {
        const requiredFields = ["name", "lastname", "email", "phone_number", "office_number"];
        for (const field of requiredFields) {
            if (!editData[field]) {
                toast.warn("Усі поля профілю повинні бути заповнені");
                return;
            }
        }

        try {
            const token = localStorage.getItem("token");

            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors/me`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(editData),
            });

            if (!response.ok) throw new Error("Помилка при оновленні профілю");

            const updatedDoctor = await response.json();
            setDoctor(updatedDoctor);
            toast.success("Профіль успішно оновлено");
        } catch (error) {
            console.error(error);
            toast.error("Не вдалося оновити профіль");
        }
    };

    const handlePasswordChange = async () => {
        const { oldPassword, newPassword, confirmNewPassword } = passwordData;

        if (!oldPassword || !newPassword || !confirmNewPassword) {
            toast.warn("Усі поля пароля повинні бути заповнені");
            return;
        }

        if (newPassword !== confirmNewPassword) {
            toast.warn("Новий пароль та підтвердження не збігаються");
            return;
        }

        try {
            const token = localStorage.getItem("token");

            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors/me/password`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(passwordData),
            });

            const result = await response.text();
            if (!response.ok) throw new Error(result);

            setPasswordData({ oldPassword: "", newPassword: "", confirmNewPassword: "" });
            toast.success("Пароль успішно змінено");
        } catch (error) {
            console.error(error);
            toast.error("Помилка при зміні пароля: " + error.message);
        }
    };

    if (!doctor) {
        return (
            <div className="profile-loading">
                <div className="spinner"></div>
                <span>Завантаження...</span>
            </div>
        );
    }

    return (
        <div className="profile-container">
            <ToastContainer />
            <h2>Профіль лікаря</h2>

            <div className="profile-form">
                <label>Ім’я:
                    <input name="name" value={editData.name} onChange={handleEditChange} />
                </label>

                <label>Прізвище:
                    <input name="lastname" value={editData.lastname} onChange={handleEditChange} />
                </label>

                <label>Email:
                    <input name="email" value={editData.email} onChange={handleEditChange} />
                </label>

                <label>Телефон:
                    <input name="phone_number" value={editData.phone_number} onChange={handleEditChange} />
                </label>

                <label>Кабінет №:
                    <input type="number" name="office_number" value={editData.office_number} onChange={handleEditChange} />
                </label>

                <label>Клініка:
                    <input value={clinicName} disabled />
                </label>

                <button onClick={handleSaveProfile}>Зберегти зміни</button>
            </div>

            <hr />

            <div className="password-form">
                <h3>Змінити пароль</h3>

                <label>Старий пароль:
                    <input
                        type="password"
                        name="oldPassword"
                        value={passwordData.oldPassword}
                        onChange={(e) => setPasswordData({ ...passwordData, oldPassword: e.target.value })}
                    />
                </label>

                <label>Новий пароль:
                    <input
                        type="password"
                        name="newPassword"
                        value={passwordData.newPassword}
                        onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                    />
                </label>

                <label>Підтвердження пароля:
                    <input
                        type="password"
                        name="confirmNewPassword"
                        value={passwordData.confirmNewPassword}
                        onChange={(e) => setPasswordData({ ...passwordData, confirmNewPassword: e.target.value })}
                    />
                </label>

                <button onClick={handlePasswordChange}>Оновити пароль</button>
            </div>
        </div>
    );
};

export default DoctorProfilePage;
