import React, { useEffect, useState } from 'react';
import '../styles/clinicsPage.css';
import AddClinicModal from '../components/AddClinicModal';
import ConfirmPasswordModal from '../components/ConfirmPasswordModal';
import { Toaster, toast } from "react-hot-toast";

const ClinicsPage = () => {
    const [clinics, setClinics] = useState([]);
    const [selectedClinicId, setSelectedClinicId] = useState(null);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [editClinicId, setEditClinicId] = useState(null);
    const [editForm, setEditForm] = useState({});
    const [showAddModal, setShowAddModal] = useState(false);


    const fetchClinics = async () => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/clinics`);
            const data = await res.json();
            setClinics(data);
        } catch (err) {
            console.error('Помилка при завантаженні медичних закладів:', err);
        }
    };

    useEffect(() => {
        fetchClinics();
    }, []);

    const handleDelete = (id) => {
        setSelectedClinicId(id);
        setShowConfirmModal(true);
    };

    const confirmDelete = async (password) => {
        try {
            const checkRes = await fetch(`${process.env.REACT_APP_BASE_URL}/admin/verify-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ password })
            });

            const checkData = await checkRes.json();

            if (!checkData.success) {
                toast.error("Невірний пароль!");
                return
            }

            await fetch(`${process.env.REACT_APP_BASE_URL}/clinics/${selectedClinicId}`, {
                method: 'DELETE',
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });

            setClinics(clinics.filter(c => c.id !== selectedClinicId));
            setShowConfirmModal(false);
            toast.success("Видалення успішне!");

        } catch (err) {
            alert(err.message || 'Помилка при видаленні клініки');
        }
    };

    const handleEdit = (clinic) => {
        setEditClinicId(clinic.id);
        setEditForm({ ...clinic });
    };

    const handleCancelEdit = () => {
        setEditClinicId(null);
        setEditForm({});
    };

    const handleFormChange = (field, value) => {
        setEditForm(prev => ({ ...prev, [field]: value }));
    };

    const handleSaveEdit = async (clinic_id) => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/clinics/${clinic_id}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(editForm)
            });

            if (!res.ok) throw new Error('Помилка при оновленні клініки');

            const updated = await res.json();
            setClinics(clinics.map(c => c.id === updated.id ? updated : c));
            setEditClinicId(null);
            setEditForm({});
            toast.success("Зміни успішно збережені!");
        } catch (err) {
            alert(err.message || 'Помилка при оновленні клініки');
        }
    };

    return (
        <div className="clinics-container">
            <h2>Медичні заклади</h2>
            <button className="add-btn" onClick={() => setShowAddModal(true)}>Додати новий медичний заклад</button>

            <table className="clinics-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Назва</th>
                    <th>Місто</th>
                    <th>Адреса</th>
                    <th>Опис</th>
                    <th>Дії</th>
                </tr>
                </thead>
                <tbody>
                {clinics.map(clinic => (
                    <tr key={clinic.id}>
                        <td>{clinic.id}</td>
                        {editClinicId === clinic.id ? (
                            <>
                                <td>
                                    <textarea
                                        value={editForm.name}
                                        onChange={e => handleFormChange('name', e.target.value)}
                                    />
                                </td>
                                <td>
                                    <textarea
                                        value={editForm.city}
                                        onChange={e => handleFormChange('city', e.target.value)}
                                    />
                                </td>
                                <td>
                                    <textarea
                                        value={editForm.address}
                                        onChange={e => handleFormChange('address', e.target.value)}
                                    />
                                </td>
                                <td>
                                    <textarea
                                        value={editForm.description}
                                        onChange={e => handleFormChange('description', e.target.value)}
                                    />
                                </td>
                                <td>
                                    <button className="save-btn" onClick={() => handleSaveEdit(clinic.id)}>Зберегти</button>
                                    <button className="cancel-btn" onClick={handleCancelEdit}>Скасувати</button>
                                </td>
                            </>
                        ) : (
                            <>
                                <td>{clinic.name}</td>
                                <td>{clinic.city}</td>
                                <td>{clinic.address}</td>
                                <td>{clinic.description}</td>
                                <td>
                                    <button className="edit-btn" onClick={() => handleEdit(clinic)}>Редагувати</button>
                                    <button className="delete-btn" onClick={() => handleDelete(clinic.id)}>Видалити</button>
                                </td>

                            </>
                        )}
                    </tr>
                ))}
                </tbody>
            </table>

            {showAddModal && (
                <AddClinicModal
                    onClose={() => setShowAddModal(false)}
                    onClinicAdded={(newClinic) => setClinics(prev => [...prev, newClinic])}
                />
            )}
            {showConfirmModal && (
                <ConfirmPasswordModal
                    onConfirm={confirmDelete}
                    onCancel={() => setShowConfirmModal(false)}
                />
            )}
        </div>
    );
};

export default ClinicsPage;
