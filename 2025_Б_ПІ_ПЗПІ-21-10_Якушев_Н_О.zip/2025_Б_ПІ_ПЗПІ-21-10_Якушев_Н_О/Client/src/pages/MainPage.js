import React from 'react';
import '../styles/mainPage.css';
import { useNavigate } from 'react-router-dom';

function MainPage() {
    const navigate = useNavigate();

    return (
        <div className="mail-container">
            <header className="mail-header">
                <h1>Система обліку щеплень VacHealth</h1>
                <p>Надійний сервіс для управління вакцинацією пацієнтів</p>
            </header>

            <section className="mail-actions">
                <button onClick={() => navigate('/patient/registration')}>Створити аккаунт</button>
                <button onClick={() => navigate('/patient/login')}>Увійти як пацієнт</button>
                <button onClick={() => navigate('/doctor/login')}>Увійти як лікар</button>
                <button onClick={() => navigate('/appointments/book')}>Спробувати функціонал</button>
            </section>

            <section className="mail-features">
                <div className="feature-card">
                    <h2>Запис на щеплення</h2>
                    <p>Пацієнти можуть легко записатися на щеплення, обравши зручний час та медичних заклад.</p>
                </div>
                <div className="feature-card">
                    <h2>Управління прийомами</h2>
                    <p>Лікарі переглядають прийоми, проводять щеплення та вносять дані.</p>
                </div>
                <div className="feature-card">
                    <h2>Електронна довідка про вакцинацію</h2>
                    <p>Система автоматично формує офіційні довідки про щеплення у PDF-форматі.</p>
                </div>
                <div className="feature-card">
                    <h2>Нагадування</h2>
                    <p>Пацієнти отримують нагадування про прийоми на щеплення електронною поштою.</p>
                </div>
            </section>
        </div>
    );
}

export default MainPage;
