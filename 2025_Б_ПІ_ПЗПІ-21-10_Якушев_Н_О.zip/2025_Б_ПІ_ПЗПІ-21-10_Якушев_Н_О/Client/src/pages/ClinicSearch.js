import React, { useEffect, useState } from 'react';
import './../styles/clinicSearch.css';
import { ToastContainer, toast } from "react-toastify";
import AppointmentModal from '../components/AppointmentModal';
import { useNavigate } from 'react-router-dom'
const ClinicSearch = () => {
    const [clinics, setClinics] = useState([]);
    const [selectedClinic, setSelectedClinic] = useState(null);
    const [cityQuery, setCityQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [selectedVaccine, setSelectedVaccine] = useState('');
    const [vaccines, setVaccines] = useState([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [appointmentInfo, setAppointmentInfo] = useState(null);
    const navigate = useNavigate()
    const patientId = localStorage.getItem("userId");
    const isAuthenticated = !!localStorage.getItem("token");

    const fetchClinics = async () => {
        setIsLoading(true);
        try {
            const response = await fetch(
                cityQuery.trim()
                    ? `${process.env.REACT_APP_BASE_URL}/clinics/by-city?city=${encodeURIComponent(cityQuery)}`
                    : `${process.env.REACT_APP_BASE_URL}/clinics`
            );
            const data = await response.json();
            setClinics(data);
        } catch (err) {
            console.error('Помилка при завантаженні клінік:', err);
        }
        setIsLoading(false);
    };

    useEffect(() => {
        fetchClinics();
    }, []);

    useEffect(() => {
        const fetchVaccines = async () => {
            if (!selectedClinic) return;
            try {
                const response = await fetch(`${process.env.REACT_APP_BASE_URL}/vaccines`);
                const data = await response.json();
                setVaccines(data);
                if (data.length > 0) {
                    setSelectedVaccine(data[0].id);
                }
            } catch (err) {
                console.error('Помилка при завантаженні вакцин:', err);
            }
        };

        fetchVaccines();
    }, [selectedClinic]);

    const handleSearch = (e) => {
        e.preventDefault();
        fetchClinics();
    };

    const handleFinalSubmit = async () => {
        if (!isAuthenticated) {
            toast.info("Зареєструйтесь та авторизуйтесь в системі!", {
                position: "top-center",
                autoClose: 2000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
            });
            return
        }
        try {
            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/appointments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    patient_id: patientId,
                    doctor_id: appointmentInfo.doctor.id,
                    datetime: appointmentInfo.time,
                    status: 'заплановано',
                }),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Не вдалося створити запис');
            }

            const inoculationResponse = await fetch(`${process.env.REACT_APP_BASE_URL}/inoculations`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    appointment_id: result.id,
                    vaccine_id: selectedVaccine
                }),
            });

            const inoculationResult = await inoculationResponse.json();

            if (!inoculationResponse.ok) {
                console.warn('Щеплення не створено:', inoculationResult.message);
                toast.error("Запис створено, але щеплення не додано.");
            } else {
                toast.success("Запис на прийом і щеплення успішно створено");
            }

            setAppointmentInfo(null);
            setTimeout(() => {
                window.location.href = "/appointments";
            }, 1500);

        } catch (err) {
            console.error('Помилка при записі:', err);
            toast.error("Помилка при створенні запису. Спробуйте пізніше.");
        }
    };


    return (
        <div className="clinic-search-container">
            <ToastContainer />
            <div className="clinic-list">
                <h3 className="section-title">Скористуйтесь пошуком та оберіть медичний заклад для щеплення зі списку</h3>
                <form onSubmit={handleSearch} className="search-form">
                    <input
                        type="text"
                        placeholder="Пошук за містом..."
                        value={cityQuery}
                        onChange={(e) => setCityQuery(e.target.value)}
                        className="search-input"
                    />
                </form>

                {isLoading ? (
                    <div className="loading-spinner-container">
                        <div className="loading-spinner"></div>
                        <p className="loading-text">Завантаження...</p>
                    </div>
                ) : clinics.length === 0 ? (
                    <p className="info-message">Немає результатів</p>
                ) : (
                    <ul className="clinic-items">
                        {clinics.map((clinic) => (
                            <li
                                key={clinic.id}
                                onClick={() => {
                                    setSelectedClinic(clinic);
                                    setAppointmentInfo(null);
                                }}                                className={`clinic-item ${selectedClinic?.id === clinic.id ? 'selected' : ''}`}
                            >
                                <p className="clinic-name">{clinic.name}</p>
                                <p className="clinic-city">{clinic.city}</p>
                            </li>
                        ))}
                    </ul>
                )}
            </div>

            <div className="clinic-details">
                {selectedClinic ? (
                    <div>
                        <h2 className="clinic-title">{selectedClinic.name}</h2>
                        <p><strong>Місто:</strong> {selectedClinic.city}</p>
                        <p><strong>Адреса:</strong> {selectedClinic.address}</p>
                        <p><strong>Опис:</strong> {selectedClinic.description}</p>

                        <div className="appointment-section">
                            <div className="fade-line"></div>
                            <h3>Оберіть вакцину, яку бажаєте виконати, та доступну дату та час для прийому на щеплення</h3>
                            <div className="fade-line"></div>
                            <div className="vaccine-select-row">
                                <div>
                                    <label><strong>Вакцина:</strong></label>
                                    <select value={selectedVaccine} onChange={(e) => setSelectedVaccine(e.target.value)}>
                                        {vaccines.map((vaccine) => (
                                            <option key={vaccine.id} value={vaccine.id}>
                                                {vaccine.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <button className="info-button" onClick={() => navigate('/vaccines')}>
                                    Ознайомитися з вакцинами
                                </button>
                            </div>
                            <button onClick={() => setIsModalOpen(true)}>Обрати дату</button>
                        </div>

                        {appointmentInfo && (
                            <div className="confirmation-section">
                                <h4>Підтвердження запису</h4>
                                <p><strong>Дата:</strong> {appointmentInfo.date}</p>
                                <p><strong>Час:</strong> {appointmentInfo.time.slice(11, 16)}</p>
                                <button onClick={handleFinalSubmit}>Підтвердити запис</button>
                            </div>
                        )}
                    </div>
                ) : (
                    <p className="info-message">Оберіть клініку зі списку для перегляду деталей</p>
                )}
            </div>

            {isModalOpen && selectedClinic && (
                <AppointmentModal
                    clinicId={selectedClinic.id}
                    onClose={() => setIsModalOpen(false)}
                    onConfirmSelection={(info) => {
                        setAppointmentInfo(info);
                        setIsModalOpen(false);
                    }}
                />
            )}
        </div>
    );
};

export default ClinicSearch;
