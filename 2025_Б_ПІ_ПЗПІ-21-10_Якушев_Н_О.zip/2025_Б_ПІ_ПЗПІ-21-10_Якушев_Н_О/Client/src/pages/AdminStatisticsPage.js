import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const periods = [
    { id: 'year-last', label: 'Попередній рік' },
    { id: 'year-now', label: 'Поточний рік' },
    { id: 'month-last', label: 'Попередній місяць' },
    { id: 'month-now', label: 'Поточний місяць' },
    { id: 'day', label: 'Останні 10 днів' },
];

export default function AdminStatisticsPage() {
    const [selectedPeriod, setSelectedPeriod] = useState('year-last');
    const [chartData, setChartData] = useState({ labels: [], data: [] });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        async function fetchStatistics() {
            setLoading(true);
            setError(null);
            try {
                const response = await fetch(`${process.env.REACT_APP_BASE_URL}/statistics/admin?type=${selectedPeriod}`, {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (!response.ok) {
                    throw new Error(`Помилка: ${response.status}`);
                }

                const json = await response.json();

                if (json.labels && json.data) {
                    setChartData({ labels: json.labels, data: json.data });
                } else {
                    throw new Error('Неправильний формат відповіді API');
                }
            } catch (err) {
                setError(err.message);
                setChartData({ labels: [], data: [] });
            } finally {
                setLoading(false);
            }
        }

        fetchStatistics();
    }, [selectedPeriod]);

    const data = {
        labels: chartData.labels,
        datasets: [
            {
                label: 'Кількість зареєстрованих пацієнтів',
                data: chartData.data,
                backgroundColor: 'rgba(53, 162, 235, 0.7)',
            },
        ],
    };

    const options = {
        responsive: true,
        plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Статистика пацієнтів' },
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: { stepSize: 10 },
            },
        },
    };

    return (
        <div style={{ maxWidth: 900, margin: 'auto', padding: 20 }}>
            <h1>Статистика реєстрацій пацієнтів</h1>

            <div style={{ marginBottom: 20 }}>
                {periods.map(({ id, label }) => (
                    <button
                        key={id}
                        onClick={() => setSelectedPeriod(id)}
                        style={{
                            marginRight: 10,
                            padding: '8px 16px',
                            backgroundColor: selectedPeriod === id ? '#357edd' : '#eee',
                            color: selectedPeriod === id ? '#fff' : '#333',
                            border: 'none',
                            borderRadius: 4,
                            cursor: 'pointer',
                        }}
                    >
                        {label}
                    </button>
                ))}
            </div>

            {loading && (
                <div style={{ display: 'flex', justifyContent: 'center', marginTop: 40 }}>
                    <div className="spinner" />
                </div>
            )}

            {error && <p style={{ color: 'red' }}>Помилка: {error}</p>}

            {!loading && !error && chartData.labels.length > 0 ? (
                <Bar options={options} data={data} />
            ) : !loading && !error ? (
                <p>Немає даних для відображення</p>
            ) : null}

            <style>
                {`
                    .spinner {
                        border: 5px solid #f3f3f3;
                        border-top: 5px solid #3498db;
                        border-radius: 50%;
                        width: 40px;
                        height: 40px;
                        animation: spin 1s linear infinite;
                    }

                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                `}
            </style>
        </div>
    );
}
