import React from "react";
import { useNavigate } from "react-router-dom";
import "./../styles/dashboard.css";

const DashboardPage = () => {
    const navigate = useNavigate();

    const userId = localStorage.getItem("userId");
    const doctorId = localStorage.getItem("doctorId");
    const adminId = localStorage.getItem("adminId");

    return (
        <div className="dashboard-container">
            <h2 className="dashboard-title">Доступні можливості</h2>
            <div className="dashboard-grid">
                {userId && (
                    <>
                        <div className="dashboard-card">
                            <h3>Особистий кабінет</h3>
                            <p>Перегляньте вашу особисту інформацію, внесіть зміни до профілю або оновіть контактні дані.</p>
                            <button onClick={() => navigate("/patient/profile")}>Перейти</button>
                        </div>

                        <div className="dashboard-card">
                            <h3>Записатися на щеплення</h3>
                            <p>Оберіть вакцину, зручну дату, та клініку для запису на щеплення.</p>
                            <button onClick={() => navigate("/appointments/book")}>Перейти</button>
                        </div>

                        <div className="dashboard-card">
                            <h3>Мої записи на щеплення</h3>
                            <p>Перегляньте історію ваших записів, дізнайтеся деталі або скасуйте візит.</p>
                            <button onClick={() => navigate("/appointments")}>Перейти</button>
                        </div>

                        <div className="dashboard-card">
                            <h3>Мої щеплення</h3>
                            <p>Перегляньте свої щеплення. Можете сформувати електронну довідку про вакцинацію.</p>
                            <button onClick={() => navigate("/my-vaccines")}>Перейти</button>
                        </div>

                        <div className="dashboard-card">
                            <h3>Доступні вакцини</h3>
                            <p>Перегляньте доступні вакцини та ознайомтесь з основною інформацією про них.</p>
                            <button onClick={() => navigate("/vaccines")}>Перейти</button>
                        </div>

                        <div className="dashboard-card">
                            <h3>Поставити питання</h3>
                            <p>Отримайте відповідь на свої запитання щодо вакцинації та шеплень від нейромережі.</p>
                            <button onClick={() => navigate("/chat")}>Перейти</button>
                        </div>
                    </>
                )}

                {doctorId && (
                    <>
                        <div className="dashboard-card">
                            <h3>Особистий кабінет</h3>
                            <p>Перегляньте вашу особисту інформацію, внесіть зміни до профілю або оновіть контактні дані.</p>
                            <button onClick={() => navigate("/doctor/profile")}>Перейти</button>
                        </div>
                        <div className="dashboard-card">
                            <h3>Прийоми пацієнтів</h3>
                            <p>Перегляньте всі прийоми на щеплення, які призначені саме вам як лікарю.</p>
                            <button onClick={() => navigate("/doctor/appointments")}>Перейти</button>
                        </div>
                        <div className="dashboard-card">
                            <h3>Статистика</h3>
                            <p>Перегляньте дані про кількість ваших прийомів на шеплення в графічному вигляді.</p>
                            <button onClick={() => navigate("/doctor/statistics")}>Перейти</button>
                        </div>
                    </>
                )}

                {adminId && (
                    <>
                        <div className="dashboard-card">
                            <h3>Медичні заклади</h3>
                            <p>Реєстарція медичних закладів та робота з даними про них.</p>
                            <button onClick={() => navigate("/clinics")}>Перейти</button>
                        </div>
                        <div className="dashboard-card">
                            <h3>Лікарі</h3>
                            <p>Реєстарція лікарів та робота з їх даними.</p>
                            <button onClick={() => navigate("/doctors")}>Перейти</button>
                        </div>
                        <div className="dashboard-card">
                            <h3>Вакцини</h3>
                            <p>Додавання, перегляд, редагування, та видалення даних про вакцини.</p>
                            <button onClick={() => navigate("/vaccine")}>Перейти</button>
                        </div>
                        <div className="dashboard-card">
                            <h3>Статистика</h3>
                            <p>Перегляд статистичних даних в графічому вигляді.</p>
                            <button onClick={() => navigate("/admin/statistics")}>Перейти</button>
                        </div>

                    </>
                )}
            </div>
        </div>
    );
};

export default DashboardPage;
