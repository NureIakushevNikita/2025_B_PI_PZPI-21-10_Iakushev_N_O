import React, { useState } from "react";
import "./../styles/login.css";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import BackButton from "../components/BackButton";

const LoginPage = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();
        setError("");

        try {
            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/patients/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                const message = await response.text();
                throw new Error(message);
            }

            const data = await response.json();
            const { patient, token } = data;

            localStorage.setItem("token", token);
            localStorage.setItem("userId", patient.id);

            toast.success("Успішна авторизація!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
            });

            setTimeout(() => {
                window.location.href = "/dashboard";
            }, 2500);

        } catch (err) {
            setError(err.message || "Помилка при вході");
            toast.error("Помилка при вході", {
                position: "top-right",
                autoClose: 3000,
            });
        }
    };

    return (
        <div className="login-container">

            <ToastContainer />
            <form className="login-form" onSubmit={handleLogin}>
                <h2>Авторизація</h2>
                {error && <p style={{ color: "red" }}>{error}</p>}
                <input
                    type="email"
                    placeholder="Електронна пошта"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Пароль"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit">Увійти</button>
                <p className="register-text">
                    Ще не маєте акаунту? <a href="/patient/registration">Зареєструватися</a>
                </p>
            </form>
        </div>
    );
};

export default LoginPage;
