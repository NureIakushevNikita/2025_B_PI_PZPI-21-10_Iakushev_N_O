import React, { useState } from 'react';
import '../styles/chat.css';

const ChatPage = () => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSend = async () => {
        if (!question.trim()) return;

        setLoading(true);
        setAnswer('');

        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question }),
            });

            const data = await res.json();
            setAnswer(data.answer || 'Немає відповіді.');
        } catch (err) {
            console.error('Помилка при відправці:', err);
            setAnswer('Помилка при відправці запиту.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="chat-container">
            <h2>Чат з помічником</h2>

            <textarea
                placeholder="Введіть ваше питання..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
            />

            <button onClick={handleSend} disabled={loading}>
                {loading ? 'Відправка...' : 'Відправити'}
            </button>

            <div className="chat-response">
                {loading ? <div className="loader">Відповідь генерується<span className="dots"></span></div> : answer}
            </div>
        </div>
    );
};

export default ChatPage;
