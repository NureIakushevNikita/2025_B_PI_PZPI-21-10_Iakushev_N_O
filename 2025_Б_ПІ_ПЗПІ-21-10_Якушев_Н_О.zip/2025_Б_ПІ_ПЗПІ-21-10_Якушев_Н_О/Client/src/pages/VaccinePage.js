import React, { useEffect, useState } from 'react';
import '../styles/clinicsPage.css';
import ConfirmPasswordModal from '../components/ConfirmPasswordModal';
import AddVaccineModal from '../components/AddVaccineModal';
import { Toaster, toast } from "react-hot-toast";

const VaccinePage = () => {
    const [vaccines, setVaccines] = useState([]);
    const [selectedVaccineId, setSelectedVaccineId] = useState(null);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [editVaccineId, setEditVaccineId] = useState(null);
    const [editForm, setEditForm] = useState({});
    const [showAddModal, setShowAddModal] = useState(false);

    const fetchVaccines = async () => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/vaccines`);
            const data = await res.json();
            setVaccines(data);
        } catch (err) {
            console.error('Помилка при завантаженні вакцин:', err);
        }
    };

    useEffect(() => {
        fetchVaccines();
    }, []);

    const handleDelete = (id) => {
        setSelectedVaccineId(id);
        setShowConfirmModal(true);
    };

    const confirmDelete = async (password) => {
        try {
            const checkRes = await fetch(`${process.env.REACT_APP_BASE_URL}/admin/verify-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ password })
            });

            const checkData = await checkRes.json();

            if (!checkData.success) {
                toast.error("Невірний пароль!");
                return;
            }

            await fetch(`${process.env.REACT_APP_BASE_URL}/vaccines/${selectedVaccineId}`, {
                method: 'DELETE',
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });

            setVaccines(vaccines.filter(v => v.id !== selectedVaccineId));
            setShowConfirmModal(false);
            toast.success("Видалення успішне!");
        } catch (err) {
            alert(err.message || 'Помилка при видаленні вакцини');
        }
    };

    const handleEdit = (vaccine) => {
        setEditVaccineId(vaccine.id);
        setEditForm({ ...vaccine });
    };

    const handleCancelEdit = () => {
        setEditVaccineId(null);
        setEditForm({});
    };

    const handleFormChange = (field, value) => {
        setEditForm(prev => ({ ...prev, [field]: value }));
    };

    const handleSaveEdit = async (id) => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/vaccines/${id}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(editForm)
            });

            if (!res.ok) throw new Error('Помилка при оновленні вакцини');

            const updated = await res.json();
            setVaccines(vaccines.map(v => v.id === updated.id ? updated : v));
            setEditVaccineId(null);
            setEditForm({});
            toast.success("Зміни успішно збережені!");
        } catch (err) {
            alert(err.message || 'Помилка при оновленні вакцини');
        }
    };

    return (
        <div className="clinics-container">
            <Toaster />
            <h2>Вакцини</h2>
            <button className="add-btn" onClick={() => setShowAddModal(true)}>Додати нову вакцину</button>

            <table className="clinics-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Назва</th>
                    <th>Кількість доз</th>
                    <th>Опис</th>
                    <th>Дії</th>
                </tr>
                </thead>
                <tbody>
                {vaccines.map(vaccine => (
                    <tr key={vaccine.id}>
                        <td>{vaccine.id}</td>
                        {editVaccineId === vaccine.id ? (
                            <>
                                <td>
                                    <textarea
                                        value={editForm.name}
                                        onChange={e => handleFormChange('name', e.target.value)}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="number"
                                        value={editForm.repetitions_number}
                                        onChange={e => handleFormChange('doseCount', parseInt(e.target.value))}
                                    />
                                </td>
                                <td>
                                    <textarea
                                        value={editForm.description}
                                        onChange={e => handleFormChange('description', e.target.value)}
                                    />
                                </td>
                                <td>
                                    <button className="save-btn" onClick={() => handleSaveEdit(vaccine.id)}>Зберегти</button>
                                    <button className="cancel-btn" onClick={handleCancelEdit}>Скасувати</button>
                                </td>
                            </>
                        ) : (
                            <>
                                <td>{vaccine.name}</td>
                                <td>{vaccine.repetitions_number}</td>
                                <td>{vaccine.description}</td>
                                <td>
                                    <button className="edit-btn" onClick={() => handleEdit(vaccine)}>Редагувати</button>
                                    <button className="delete-btn" onClick={() => handleDelete(vaccine.id)}>Видалити</button>
                                </td>
                            </>
                        )}
                    </tr>
                ))}
                </tbody>
            </table>

            {showAddModal && (
                <AddVaccineModal
                    onClose={() => setShowAddModal(false)}
                    onVaccineAdded={(newVaccine) => setVaccines(prev => [...prev, newVaccine])}
                />
            )}
            {showConfirmModal && (
                <ConfirmPasswordModal
                    onConfirm={confirmDelete}
                    onCancel={() => setShowConfirmModal(false)}
                />
            )}
        </div>
    );
};

export default VaccinePage;
