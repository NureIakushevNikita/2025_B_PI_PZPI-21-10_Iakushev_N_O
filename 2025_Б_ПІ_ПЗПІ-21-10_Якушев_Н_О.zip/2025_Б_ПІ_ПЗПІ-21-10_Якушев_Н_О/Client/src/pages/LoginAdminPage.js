import React, { useState } from "react";
import "./../styles/login.css";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

const AdminLoginPage = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();
        setError("");

        try {
            const response = await fetch(`${process.env.REACT_APP_BASE_URL}/admin/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                const message = await response.text();
                throw new Error(message);
            }

            const data = await response.json();
            const { admin, token } = data;

            localStorage.setItem("token", token);
            localStorage.setItem("adminId", admin.id);

            toast.success("Успішна авторизація адміністратора!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
            });

            setTimeout(() => {
                window.location.href = "/dashboard";
            }, 2500);

        } catch (err) {
            toast.error("Помилка при вході адміністратора", {
                position: "top-right",
                autoClose: 3000,
            });
        }
    };

    return (
        <div className="login-container">
            <ToastContainer />
            <form className="login-form" onSubmit={handleLogin}>
                <h2>Вхід адміністратора</h2>
                {error && <p style={{ color: "red" }}>{error}</p>}
                <input
                    type="email"
                    placeholder="Електронна пошта"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Пароль"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit">Увійти</button>
            </form>
        </div>
    );
};

export default AdminLoginPage;
