import React, { useEffect, useState } from 'react';
import '../styles/vaccinations.css';

const VaccinationsPage = () => {
    const [vaccines, setVaccines] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchVaccines = async () => {
            try {
                const response = await fetch(`${process.env.REACT_APP_BASE_URL}/vaccines`);
                const data = await response.json();
                setVaccines(data);
            } catch (error) {
                console.error('Помилка при завантаженні вакцин:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchVaccines();
    }, []);

    return (
        <div className="vaccines-container">
            <h2>Інформація про вакцини</h2>

            {loading ? (
                <p className="loading">Завантаження...</p>
            ) : (
                <ul className="vaccine-list">
                    {vaccines.map((vaccine) => (
                        <li key={vaccine.id} className="vaccine-card">
                            <h3>{vaccine.name}</h3>
                            <p><strong>Кількість доз:</strong> {vaccine.repetitions_number}</p>
                            <p><strong>Опис:</strong> {vaccine.description}</p>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default VaccinationsPage;
