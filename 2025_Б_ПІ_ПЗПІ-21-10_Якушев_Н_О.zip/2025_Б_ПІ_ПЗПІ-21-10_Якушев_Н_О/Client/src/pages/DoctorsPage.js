import React, { useEffect, useState } from 'react';
import '../styles/clinicsPage.css';
import AddDoctorModal from '../components/AddDoctorModal';
import ConfirmPasswordModal from "../components/ConfirmPasswordModal";
import { Toaster, toast } from "react-hot-toast";

const DoctorsPage = () => {
    const [doctors, setDoctors] = useState([]);
    const [editDoctorId, setEditDoctorId] = useState(null);
    const [editForm, setEditForm] = useState({});
    const [showAddModal, setShowAddModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [doctorToDelete, setDoctorToDelete] = useState(null);

    const fetchDoctors = async () => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors`);
            const data = await res.json();
            console.log(data)
            setDoctors(data);
        } catch (err) {
            console.error('Помилка при завантаженні лікарів:', err);
        }
    };

    useEffect(() => {
        fetchDoctors();
    }, []);


    const handleDeleteClick = (doctor) => {
        setDoctorToDelete(doctor);
        setShowDeleteModal(true);
    };

    const handlePasswordConfirmed = async (password) => {
        try {
            // 1. Перевірка пароля
            const verifyRes = await fetch(`${process.env.REACT_APP_BASE_URL}/admin/verify-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ password })
            });

            const verifyData = await verifyRes.json();

            if (!verifyRes.ok || !verifyData.success) {
                toast.error("Пароль невірний!");
                return
            }

            const deleteRes = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors/${doctorToDelete.id}`, {
                method: 'DELETE',
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (!deleteRes.ok) {
                const errorText = await deleteRes.text();
                throw new Error(errorText || 'Помилка при видаленні лікаря');
            }

            // Оновлюємо список лікарів у стані
            setDoctors(doctors.filter(d => d.id !== doctorToDelete.id));
        } catch (err) {
            alert(err.message || 'Помилка при видаленні лікаря');
        } finally {
            setShowDeleteModal(false);
            setDoctorToDelete(null);
        }
    };



    const handleEdit = (doctor) => {
        setEditDoctorId(doctor.id);
        setEditForm({ ...doctor });
    };

    const handleCancelEdit = () => {
        setEditDoctorId(null);
        setEditForm({});
    };

    const handleFormChange = (field, value) => {
        setEditForm(prev => ({ ...prev, [field]: value }));
    };

    const handleSaveEdit = async (doctorId) => {
        try {
            const res = await fetch(`${process.env.REACT_APP_BASE_URL}/doctors/${doctorId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(editForm)
            });

            if (!res.ok) throw new Error('Помилка при оновленні лікаря');

            const updated = await res.json();
            setDoctors(doctors.map(d => d.id === updated.id ? updated : d));
            setEditDoctorId(null);
            setEditForm({});
            toast.success("Зміни успішно збережені!");
        } catch (err) {
            alert(err.message || 'Помилка при оновленні лікаря');
        }
    };

    return (
        <div className="clinics-container">
            <h2>Лікарі</h2>
            <button className="add-btn" onClick={() => setShowAddModal(true)}>Додати нового лікаря</button>

            {showAddModal && (
                <AddDoctorModal
                    onClose={() => setShowAddModal(false)}
                    onDoctorAdded={(newDoctor) => setDoctors(prev => [...prev, newDoctor])}
                />
            )}
            <table className="clinics-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Ім'я</th>
                    <th>Прізвище</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Кабінет</th>
                    <th>Медичний заклад</th>
                    <th>Дата реєстрації</th>
                    <th>Дії</th>
                </tr>
                </thead>
                <tbody>
                {doctors.map(doctor => (
                    <tr key={doctor.id}>
                        <td>{doctor.id}</td>
                        {editDoctorId === doctor.id ? (
                            <>
                                <td><textarea value={editForm.name} onChange={e => handleFormChange('name', e.target.value)} /></td>
                                <td><textarea value={editForm.lastname} onChange={e => handleFormChange('lastname', e.target.value)} /></td>
                                <td><textarea value={editForm.email} onChange={e => handleFormChange('email', e.target.value)} /></td>
                                <td><textarea value={editForm.phone_number} onChange={e => handleFormChange('phone_number', e.target.value)} /></td>
                                <td><textarea value={editForm.office_number} onChange={e => handleFormChange('office_number', e.target.value)} /></td>
                                <td>{doctor.clinic.name}</td>
                                <td>{new Date(doctor.registration_date).toLocaleDateString()}</td>
                                <td>
                                    <button className="save-btn" onClick={() => handleSaveEdit(doctor.id)}>Зберегти</button>
                                    <button className="cancel-btn" onClick={handleCancelEdit}>Скасувати</button>
                                </td>
                            </>
                        ) : (
                            <>
                                <td>{doctor.name}</td>
                                <td>{doctor.lastname}</td>
                                <td>{doctor.email}</td>
                                <td>{doctor.phone_number}</td>
                                <td>{doctor.office_number}</td>
                                <td>{doctor.clinic.name}</td>
                                <td>{new Date(doctor.registration_date).toLocaleDateString()}</td>
                                <td>
                                    <button className="edit-btn" onClick={() => handleEdit(doctor)}>Редагувати</button>
                                    <button className="delete-btn" onClick={() => handleDeleteClick(doctor)}>Видалити</button>
                                </td>
                            </>
                        )}
                    </tr>
                ))}
                </tbody>
            </table>
            {showDeleteModal && (
                <ConfirmPasswordModal
                    onConfirm={handlePasswordConfirmed}
                    onCancel={() => {
                        setShowDeleteModal(false);
                        setDoctorToDelete(null);
                    }}
                />
            )}
        </div>

    );
};

export default DoctorsPage;
