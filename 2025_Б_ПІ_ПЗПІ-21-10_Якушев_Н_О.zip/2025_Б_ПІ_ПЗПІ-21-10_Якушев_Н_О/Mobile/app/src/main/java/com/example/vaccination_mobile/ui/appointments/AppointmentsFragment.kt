package com.example.vaccination_mobile.ui.appointments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.vaccination_mobile.CreateAppointmentActivity
import com.example.vaccination_mobile.R
import com.example.vaccination_mobile.databinding.FragmentAppointmentBinding


class AppointmentFragment : Fragment() {

    private var _binding: FragmentAppointmentBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: AppointmentViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this)[AppointmentViewModel::class.java]
        _binding = FragmentAppointmentBinding.inflate(inflater, container, false)

        binding.recyclerViewClinics.layoutManager = LinearLayoutManager(context)

        binding.searchButton.setOnClickListener {
            val city = binding.searchEditText.text.toString().trim()
            if (city.isNotEmpty()) {
                viewModel.searchClinicsByCity(city)
            } else {
                Toast.makeText(context, "Введіть місто", Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.clinics.observe(viewLifecycleOwner) { clinics ->
            binding.recyclerViewClinics.adapter = ClinicAdapter(clinics)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

