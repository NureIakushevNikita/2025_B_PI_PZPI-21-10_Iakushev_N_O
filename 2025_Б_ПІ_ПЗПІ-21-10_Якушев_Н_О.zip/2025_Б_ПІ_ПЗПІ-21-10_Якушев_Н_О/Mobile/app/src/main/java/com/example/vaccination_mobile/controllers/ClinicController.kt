package com.example.vaccination_mobile.controllers

import com.example.vaccination_mobile.api.RetrofitInstance
import com.example.vaccination_mobile.models.Clinic
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object ClinicController {
    fun getClinicsByCity(city: String, onResult: (List<Clinic>?) -> Unit) {
        val call = RetrofitInstance.api.getClinicsByCity(city)

        call.enqueue(object : Callback<List<Clinic>> {
            override fun onResponse(call: Call<List<Clinic>>, response: Response<List<Clinic>>) {
                if (response.isSuccessful) {
                    onResult(response.body())
                } else {
                    onResult(null)
                }
            }

            override fun onFailure(call: Call<List<Clinic>>, t: Throwable) {
                onResult(null)
            }
        })
    }
}