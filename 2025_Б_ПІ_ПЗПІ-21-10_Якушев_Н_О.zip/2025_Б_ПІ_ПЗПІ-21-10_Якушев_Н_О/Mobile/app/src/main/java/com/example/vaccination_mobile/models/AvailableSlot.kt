package com.example.vaccination_mobile.models

data class AvailableSlot (
    val time: String
)
