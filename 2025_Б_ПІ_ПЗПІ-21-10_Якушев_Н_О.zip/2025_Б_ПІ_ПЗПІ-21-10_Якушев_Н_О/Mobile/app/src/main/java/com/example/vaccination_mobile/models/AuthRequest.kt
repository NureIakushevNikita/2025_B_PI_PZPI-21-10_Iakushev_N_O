package com.example.vaccination_mobile.models

data class AuthRequest(
    val email: String,
    val password: String
)