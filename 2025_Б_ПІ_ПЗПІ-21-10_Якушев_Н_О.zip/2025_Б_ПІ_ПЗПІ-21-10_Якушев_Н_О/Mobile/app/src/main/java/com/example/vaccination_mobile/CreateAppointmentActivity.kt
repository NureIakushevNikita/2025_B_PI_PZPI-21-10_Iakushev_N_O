package com.example.vaccination_mobile

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.vaccination_mobile.controllers.AppointmentController
import com.example.vaccination_mobile.controllers.VaccineController
import com.example.vaccination_mobile.models.AppointmentRequest
import com.example.vaccination_mobile.models.AvailableDate
import com.example.vaccination_mobile.models.AvailableSlot
import com.example.vaccination_mobile.models.DoctorId
import com.example.vaccination_mobile.models.Vaccine

class CreateAppointmentActivity : AppCompatActivity() {

    private lateinit var spinnerVaccine: Spinner
    private lateinit var spinnerDate: Spinner
    private lateinit var spinnerSlot: Spinner
    private lateinit var buttonCreateAppointment: Button


    private var vaccinesList: List<Vaccine> = emptyList()
    private var availableDates: List<AvailableDate> = emptyList()
    private var availableSlots: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_appointment)

        spinnerVaccine = findViewById(R.id.spinnerVaccine)
        spinnerDate = findViewById(R.id.spinnerDate)
        spinnerSlot = findViewById(R.id.spinnerSlot)
        buttonCreateAppointment = findViewById(R.id.buttonCreateAppointment)

        val buttonBack = findViewById<Button>(R.id.buttonBack)
        buttonBack.setOnClickListener {
            finish()
        }


        loadVaccines()
        loadAvailableDates()
        buttonCreateAppointment.setOnClickListener {
            createAppointment()
        }


        spinnerDate.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedDate = availableDates[position].date
                val selectedDoctor = availableDates[position].availableDoctors[0].id
                loadAvailableSlots(selectedDate, selectedDoctor)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }


    }

    private fun createAppointment() {
        val selectedDatePosition = spinnerDate.selectedItemPosition
        val selectedSlotPosition = spinnerSlot.selectedItemPosition

        if (selectedDatePosition == AdapterView.INVALID_POSITION || selectedSlotPosition == AdapterView.INVALID_POSITION) {
            Toast.makeText(this, "Будь ласка, виберіть дату і час", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedDate = availableDates[selectedDatePosition].date
        val selectedTime = availableSlots[selectedSlotPosition].substringAfter(" ")
        val doctorId = availableDates[selectedDatePosition].availableDoctors[0].id
        val patientId = 7
        println(patientId);
        val datetime = "$selectedDate $selectedTime"

        val request = AppointmentRequest(
            patient_id = patientId,
            doctor_id = doctorId,
            datetime = datetime
        )

        AppointmentController.createAppointment(request) { appointment ->
            runOnUiThread {
                if (appointment != null) {
                    Toast.makeText(this, "Запис успішно створено!", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    Toast.makeText(this, "Не вдалося створити запис", Toast.LENGTH_LONG).show()
                }
            }
        }
    }


    private fun loadVaccines() {

        VaccineController.getAllVaccines { vaccines ->
            runOnUiThread {
                if (vaccines != null && vaccines.isNotEmpty()) {
                    vaccinesList = vaccines
                    val vaccineNames = vaccines.map { it.name }
                    val adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_item,
                        vaccineNames
                    )
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinnerVaccine.adapter = adapter
                } else {
                    Toast.makeText(this, "Не вдалося завантажити вакцини", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadAvailableDates() {
        val clinicId = intent.getIntExtra("clinic_id", 1)
        AppointmentController.getAvailableDates(clinicId) { dates ->
            runOnUiThread {
                if (dates != null && dates.isNotEmpty()) {
                    availableDates = dates
                    val dateStrings = dates.map { it.date }
                    val adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_item,
                        dateStrings
                    )
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinnerDate.adapter = adapter
                } else {
                    Toast.makeText(this, "Не вдалося завантажити дати", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadAvailableSlots(date: String, availableDoctorId: Int) {
        AppointmentController.getAvailableSlots(date, availableDoctorId) { slots ->
            runOnUiThread {
                if (slots != null && slots.isNotEmpty()) {
                    availableSlots = slots
                    val timeStrings = slots.map { it.substringAfter(" ") }
                    val adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_item,
                        timeStrings
                    )
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinnerSlot.adapter = adapter
                } else {
                    Toast.makeText(this, "Немає доступних слотів на обрану дату", Toast.LENGTH_SHORT).show()
                    spinnerSlot.adapter = null
                }
            }
        }
    }
}
