package com.example.vaccination_mobile.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.vaccination_mobile.R
import com.example.vaccination_mobile.models.AppointmentsResponse
import java.text.SimpleDateFormat
import java.util.*

class AppointmentsAdapter(private val appointments: List<AppointmentsResponse>) :
    RecyclerView.Adapter<AppointmentsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val clinicName: TextView = view.findViewById(R.id.clinicTextView)
        val dateTime: TextView = view.findViewById(R.id.dateTimeTextView)
        val doctor: TextView = view.findViewById(R.id.doctorTextView)
        val vaccine: TextView = view.findViewById(R.id.vaccineTextView)
        val office: TextView = view.findViewById(R.id.officeTextView)
        val status: TextView = view.findViewById(R.id.statusTextView)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.appointment_item, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = appointments.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = appointments[position]

        val calendar = Calendar.getInstance()
        calendar.time = item.datetime
        calendar.add(Calendar.HOUR_OF_DAY, -6)

        val formatter = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault())
        val formattedDate = formatter.format(calendar.time)

        holder.clinicName.text = "${item.doctor.clinic.name}"
        holder.dateTime.text = "Дата: $formattedDate"
        holder.doctor.text = "Лікар: ${item.doctor.name} ${item.doctor.lastname}"
        holder.status.text = "Статус: ${item.status}"
        holder.office.text = "Кабінет № ${item.doctor.office_number}"

        val inoculation = item.inoculations.firstOrNull()
        holder.vaccine.text = inoculation?.let {
            "Вакцина: ${it.vaccine.name} (${it.dose_number} доза)"
        } ?: "Вакцина: Вакцина проти гепатиту А"
    }
}
