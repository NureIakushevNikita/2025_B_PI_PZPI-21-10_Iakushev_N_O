package com.example.vaccination_mobile.models

data class DoctorId(
    val id: Int
)