package com.example.vaccination_mobile.models

import java.util.Date

data class Appointment(
    val id: Int,
    val patient_id: Int,
    val doctor_id: String,
    val datetime: String,
    val status: String,
    val appointment_datetime: String,
    val dose_number: Int
)
