package com.example.vaccination_mobile.models

import java.util.Date

data class AppointmentRequest(
    val patient_id: Int,
    val doctor_id: Int,
    val datetime: String
)
