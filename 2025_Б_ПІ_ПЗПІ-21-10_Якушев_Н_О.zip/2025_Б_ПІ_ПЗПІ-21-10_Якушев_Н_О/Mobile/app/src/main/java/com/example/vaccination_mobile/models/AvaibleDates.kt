package com.example.vaccination_mobile.models

data class AvailableDate(
    val date: String,
    val availableDoctors: List<DoctorId>
)