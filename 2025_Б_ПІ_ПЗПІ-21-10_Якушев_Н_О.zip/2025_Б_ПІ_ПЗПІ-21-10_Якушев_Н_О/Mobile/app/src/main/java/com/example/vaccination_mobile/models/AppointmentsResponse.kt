package com.example.vaccination_mobile.models

import java.util.Date

data class AppointmentsResponse (
    val datetime: Date,
    val status: String,
    val doctor: Doctor,
    val inoculations: List<Inoculation>,
    val message: String
)

data class Inoculation (
    val dose_number: Int,
    val vaccine: Vaccine
)

data class Doctor (
    val name: String,
    val lastname: String,
    val office_number: Int,
    val clinic: Clinic
)


