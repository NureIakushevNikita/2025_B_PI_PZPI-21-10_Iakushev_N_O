package com.example.vaccination_mobile.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.vaccination_mobile.controllers.AppointmentController
import com.example.vaccination_mobile.databinding.FragmentHomeBinding
import com.example.vaccination_mobile.models.AppointmentsResponse

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NywiZW1haWwiOiJuYWt1c2V2QGdtYWlsLmNvbSIsImlhdCI6MTc0OTQxODgyNCwiZXhwIjoxNzQ5NTA1MjI0fQ.jhPn2i2T85hKY-1ZhbPODvGRjhvEsuqX3glHRwhGePg"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        binding.appointmentsRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        loadAppointments()

        return binding.root
    }

    private fun loadAppointments() {
        AppointmentController.getMyAppointments(token) { appointments ->
            activity?.runOnUiThread {
                if (appointments != null) {
                    val adapter = AppointmentsAdapter(appointments)
                    binding.appointmentsRecyclerView.adapter = adapter
                } else {
                    Toast.makeText(requireContext(), "Не вдалося завантажити прийоми", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
