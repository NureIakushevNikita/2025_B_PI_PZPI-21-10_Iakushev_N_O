package com.example.vaccination_mobile.models

import java.util.Date

data class AuthResponse(
    val patient: Patient,
    val token: String,
)

data class Patient (
    val id: Int,
    val name: String,
    val lastname: String,
    val birthday: Date
)