package com.example.vaccination_mobile.models

data class CertificateRequest(
    val vaccine_id: Int,
    val vaccinationData: List<VaccinationData>
)

data class VaccinationData(
    val vaccine_id: Int,
    val vaccine_name: String,
    val current_doses: Int,
    val necessary_doses: Int,
    val message1: String,
    val patient: Patient,
    val doctor: Doctor,
    val clinic: Clinic,
    val appointments: List<Appointment>
)