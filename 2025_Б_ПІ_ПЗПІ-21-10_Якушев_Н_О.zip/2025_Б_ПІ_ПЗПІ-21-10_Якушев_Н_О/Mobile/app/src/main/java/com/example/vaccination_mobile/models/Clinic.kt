package com.example.vaccination_mobile.models

data class Clinic(
    val id: Int,
    val name: String,
    val address: String,
    val city: String,
    val description: String?
)
