package com.example.vaccination_mobile

import android.os.Bundle
import android.widget.Button
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.vaccination_mobile.controllers.AuthController
import com.example.vaccination_mobile.controllers.AppointmentController

import com.example.vaccination_mobile.databinding.ActivityMainBinding


import android.content.Intent
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.vaccination_mobile.controllers.CertificateController
import com.example.vaccination_mobile.models.CertificateRequest

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            val token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NywiZW1haWwiOiJuYWt1c2V2NjZAZ21haWwuY29tIiwiaWF0IjoxNzQ5MzI2Nzc4LCJleHAiOjE3NDk0MTMxNzh9.r_0HbS9nSCV2503Ay6c8RKPt3uOvhfV2flkWRSmR4QA"


            AuthController.loginUser(email, password) { authResponse ->
                println(authResponse)
                println(email)
                println(password)
                if (authResponse != null) {
                    AppointmentController.getMyAppointments(authResponse.token) {appointmentResponse ->
                        println(authResponse.token)
                        println(appointmentResponse)

                    }
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.putExtra("TOKEN", authResponse.token)
                    intent.putExtra("ID", authResponse.patient.id)
                    val patIf = authResponse.patient.id
                    println(patIf)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Невірний логін або пароль!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
