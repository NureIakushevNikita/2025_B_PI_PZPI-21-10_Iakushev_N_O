package com.example.vaccination_mobile.controllers

import com.example.vaccination_mobile.api.RetrofitInstance
import com.example.vaccination_mobile.models.Vaccine
import okhttp3.Response
import retrofit2.Call

object VaccineController {
    fun getAllVaccines(onResult: (List<Vaccine>?) -> Unit) {
        val call = RetrofitInstance.api.getAllVaccines()
        call.enqueue(object : retrofit2.Callback<List<Vaccine>> {
            override fun onResponse(call: Call<List<Vaccine>>, response: retrofit2.Response<List<Vaccine>>) {
                if (response.isSuccessful) {
                    onResult(response.body())
                } else {
                    onResult(null)
                }
            }

            override fun onFailure(call: Call<List<Vaccine>>, t: Throwable) {
                onResult(null)
            }
        })
    }
}