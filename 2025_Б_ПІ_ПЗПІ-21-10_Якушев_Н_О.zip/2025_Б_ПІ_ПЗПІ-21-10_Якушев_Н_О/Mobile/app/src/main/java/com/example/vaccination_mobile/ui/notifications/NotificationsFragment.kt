package com.example.vaccination_mobile.ui.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.vaccination_mobile.R
import com.example.vaccination_mobile.controllers.CertificateController
import com.example.vaccination_mobile.databinding.FragmentNotificationsBinding
import com.example.vaccination_mobile.models.CertificateRequest

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!
    private val token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NywiZW1haWwiOiJuYWt1c2V2QGdtYWlsLmNvbSIsImlhdCI6MTc0OTQxODgyNCwiZXhwIjoxNzQ5NTA1MjI0fQ.jhPn2i2T85hKY-1ZhbPODvGRjhvEsuqX3glHRwhGePg" 

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root = binding.root
        val layout = root.findViewById<LinearLayout>(R.id.notificationsRoot)
        layout.removeAllViews()

        CertificateController.getMyInoculations(token) { vaccinationData ->
            if (vaccinationData != null) {
                val grouped = vaccinationData.groupBy { it.vaccine_id }

                for ((vaccineId, entries) in grouped) {
                    val context = requireContext()
                    val view = layoutInflater.inflate(R.layout.vaccine_item, layout, false)

                    val vaccineName = entries.first().vaccine_name
                    val count = entries.size

                    view.findViewById<TextView>(R.id.vaccineNameText).text = "Вакцина: $vaccineName"
                    view.findViewById<TextView>(R.id.vaccineCountText).text = "Кількість щеплень: $count"
                    view.findViewById<Button>(R.id.generateBtn).setOnClickListener {
                        val request = CertificateRequest(
                            vaccine_id = vaccineId,
                            vaccinationData = entries
                        )
                        CertificateController.generateCertificate(request, context)
                    }

                    layout.addView(view)
                }
            } else {
                Toast.makeText(requireContext(), "Не вдалося отримати дані", Toast.LENGTH_SHORT).show()
            }
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
