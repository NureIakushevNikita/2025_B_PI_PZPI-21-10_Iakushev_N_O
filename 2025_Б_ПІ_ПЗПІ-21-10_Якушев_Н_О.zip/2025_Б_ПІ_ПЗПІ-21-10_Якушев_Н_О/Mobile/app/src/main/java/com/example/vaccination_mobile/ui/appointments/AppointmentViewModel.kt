package com.example.vaccination_mobile.ui.appointments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.vaccination_mobile.controllers.ClinicController
import com.example.vaccination_mobile.models.Clinic

class AppointmentViewModel : ViewModel() {
    private val _clinics = MutableLiveData<List<Clinic>>()
    val clinics: LiveData<List<Clinic>> = _clinics

    fun searchClinicsByCity(city: String) {
        ClinicController.getClinicsByCity(city) { result ->
            _clinics.postValue(result ?: emptyList())
        }
    }
}
