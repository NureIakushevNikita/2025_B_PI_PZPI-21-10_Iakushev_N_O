package com.example.vaccination_mobile.models


data class Vaccine(
    val id: Int,
    val name: String,
    val repetitions_number: Int,
    val description: String
)