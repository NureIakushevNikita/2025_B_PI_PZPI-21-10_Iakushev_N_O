package com.example.vaccination_mobile.controllers

import android.util.Log
import com.example.vaccination_mobile.api.RetrofitInstance
import com.example.vaccination_mobile.models.Appointment
import com.example.vaccination_mobile.models.AppointmentRequest
import com.example.vaccination_mobile.models.AppointmentsResponse
import com.example.vaccination_mobile.models.AvailableSlot
import com.example.vaccination_mobile.models.AvailableDate
import com.example.vaccination_mobile.models.DoctorId
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object AppointmentController {

    private val api = RetrofitInstance.api

    fun createAppointment(request: AppointmentRequest, callback: (Appointment?) -> Unit) {
        val call = api.createAppointment(request)
        call.enqueue(object : retrofit2.Callback<Appointment> {
            override fun onResponse(call: retrofit2.Call<Appointment>, response: retrofit2.Response<Appointment>) {
                if (response.isSuccessful) {
                    callback(response.body())
                } else {
                    callback(null)
                }
            }
            override fun onFailure(call: retrofit2.Call<Appointment>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun getAvailableDates(clinicId: Int, callback: (List<AvailableDate>?) -> Unit) {
        val call = api.getAvailableDates(clinicId)
        call.enqueue(object : retrofit2.Callback<List<AvailableDate>> {
            override fun onResponse(call: retrofit2.Call<List<AvailableDate>>, response: retrofit2.Response<List<AvailableDate>>) {
                if (response.isSuccessful) {
                    callback(response.body())
                } else {
                    callback(null)
                }
            }
            override fun onFailure(call: retrofit2.Call<List<AvailableDate>>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun getAvailableSlots(date: String, doctorId: Int, callback: (List<String>?) -> Unit) {
        val call = api.getAvailableSlots(date, doctorId)
        call.enqueue(object : retrofit2.Callback<List<String>> {
            override fun onResponse(call: retrofit2.Call<List<String>>, response: retrofit2.Response<List<String>>) {
                if (response.isSuccessful) {
                    callback(response.body())
                } else {
                    callback(null)
                }
            }
            override fun onFailure(call: retrofit2.Call<List<String>>, t: Throwable) {
                callback(null)
            }
        })
    }

    fun getMyAppointments(token: String, callback: (List<AppointmentsResponse>?) -> Unit) {
        val call = api.getMyAppointments("Bearer $token")
        call.enqueue(object : Callback<List<AppointmentsResponse>> {
            override fun onResponse(
                call: Call<List<AppointmentsResponse>>,
                response: Response<List<AppointmentsResponse>>
            ) {
                Log.d("API", "Code: ${response.code()}")
                Log.d("API", "Body: ${response.body()}")
                Log.d("API", "ErrorBody: ${response.errorBody()?.string()}")

                if (response.isSuccessful) {
                    callback(response.body())
                } else {
                    callback(null)
                }
            }

            override fun onFailure(call: Call<List<AppointmentsResponse>>, t: Throwable) {
                Log.e("API", "Failure: ${t.message}", t)
                callback(null)
            }
        })
    }

}
