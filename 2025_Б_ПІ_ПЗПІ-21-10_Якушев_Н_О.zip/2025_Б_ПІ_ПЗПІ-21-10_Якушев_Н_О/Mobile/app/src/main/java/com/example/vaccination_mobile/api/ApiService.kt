package com.example.vaccination_mobile.api

import com.example.vaccination_mobile.models.Appointment
import com.example.vaccination_mobile.models.AppointmentRequest
import com.example.vaccination_mobile.models.AppointmentsResponse
import com.example.vaccination_mobile.models.AuthRequest
import com.example.vaccination_mobile.models.AuthResponse
import com.example.vaccination_mobile.models.AvailableDate
import com.example.vaccination_mobile.models.AvailableSlot
import com.example.vaccination_mobile.models.CertificateRequest
import com.example.vaccination_mobile.models.Clinic
import com.example.vaccination_mobile.models.VaccinationData
import com.example.vaccination_mobile.models.Vaccine
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Streaming

interface ApiService {
    @POST("/patients/login")
    fun loginUser(@Body authRequest: AuthRequest): Call<AuthResponse>

    @GET("clinics/by-city")
    fun getClinicsByCity(@Query("city") city: String): Call<List<Clinic>>

    @POST("appointments")
    fun createAppointment(@Body appointmentRequest: AppointmentRequest): Call<Appointment>

    @GET("appointments/get-dates")
    fun getAvailableDates(@Query("clinic_id") clinicId: Int): Call<List<AvailableDate>>

    @GET("appointments/get-slots")
    fun getAvailableSlots(
        @Query("date") date: String,
        @Query("doctor_id") doctorId: Int
    ): Call<List<String>>

    @GET("vaccines")
    fun getAllVaccines(): Call<List<Vaccine>>

    @GET("appointments/my")
    fun getMyAppointments(
        @Header("Authorization") token: String
    ): Call<List<AppointmentsResponse>>

    @GET("/inoculations")
    fun getInoculations(
        @Header("Authorization") token: String
    ): Call<List<VaccinationData>>

    @POST("/certificate")
    @Streaming // бо повертається DOCX файл
    fun generateCertificate(
        @Body request: CertificateRequest
    ): Call<ResponseBody>


}

