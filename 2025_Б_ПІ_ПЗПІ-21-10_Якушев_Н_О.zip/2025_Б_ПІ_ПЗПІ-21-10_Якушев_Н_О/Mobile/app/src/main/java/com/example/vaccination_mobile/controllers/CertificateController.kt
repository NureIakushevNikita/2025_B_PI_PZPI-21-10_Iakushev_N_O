package com.example.vaccination_mobile.controllers

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.vaccination_mobile.api.RetrofitInstance.api
import com.example.vaccination_mobile.models.AppointmentsResponse
import com.example.vaccination_mobile.models.CertificateRequest
import com.example.vaccination_mobile.models.VaccinationData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream

object CertificateController {
    fun getMyInoculations(token: String, callback: (List<VaccinationData>?) -> Unit) {
        val call = api.getInoculations("Bearer $token")
        call.enqueue(object : Callback<List<VaccinationData>> {
            override fun onResponse(
                call: Call<List<VaccinationData>>,
                response: Response<List<VaccinationData>>
            ) {
                Log.d("API", "Code: ${response.code()}")
                Log.d("API", "Body: ${response.body()}")
                Log.d("API", "ErrorBody: ${response.errorBody()?.string()}")

                if (response.isSuccessful) {
                    callback(response.body())
                } else {
                    callback(null)
                }
            }

            override fun onFailure(call: Call<List<VaccinationData>>, t: Throwable) {
                Log.e("API", "Failure: ${t.message}", t)
                callback(null)
            }
        })
    }

    fun generateCertificate(request: CertificateRequest, context: Context) {
        val call = api.generateCertificate(request)

        call.enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful && response.body() != null) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val inputStream = response.body()!!.byteStream()
                            val file = File(context.getExternalFilesDir(null), "certificate.docx")
                            val outputStream = FileOutputStream(file)

                            inputStream.copyTo(outputStream)
                            outputStream.close()
                            inputStream.close()

                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    context,
                                    "Довідку завантажено",
                                    Toast.LENGTH_LONG
                                ).show()

                                openDocxFile(context, file)
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    context,
                                    "Помилка збереження: ${e.message}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                } else {
                    Toast.makeText(context, "Не вдалося згенерувати сертифікат", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(context, "Помилка мережі: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun openDocxFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            file
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Немає програми для відкриття DOCX", Toast.LENGTH_LONG).show()
        }
    }



}