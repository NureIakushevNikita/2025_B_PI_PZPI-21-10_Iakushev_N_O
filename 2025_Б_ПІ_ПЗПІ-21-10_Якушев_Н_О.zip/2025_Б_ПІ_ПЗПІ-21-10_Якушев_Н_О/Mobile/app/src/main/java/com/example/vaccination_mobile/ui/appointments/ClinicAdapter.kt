package com.example.vaccination_mobile.ui.appointments

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.vaccination_mobile.CreateAppointmentActivity
import com.example.vaccination_mobile.R
import com.example.vaccination_mobile.models.Clinic

class ClinicAdapter(private val clinics: List<Clinic>) :
    RecyclerView.Adapter<ClinicAdapter.ClinicViewHolder>() {

    class ClinicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val clinicName: TextView = itemView.findViewById(R.id.clinic_name)
        val clinicCity: TextView = itemView.findViewById(R.id.clinic_city)
        val clinicAddress: TextView = itemView.findViewById(R.id.clinic_address)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClinicViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.clinic_item, parent, false)
        return ClinicViewHolder(view)
    }

    override fun onBindViewHolder(holder: ClinicViewHolder, position: Int) {
        val clinic = clinics[position]
        holder.clinicName.text = clinic.name
        holder.clinicCity.text = clinic.city
        holder.clinicAddress.text = clinic.address

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, CreateAppointmentActivity::class.java)
            val patientId = intent.getIntExtra("ID", 0);
            intent.putExtra("clinic_id", clinic.id)
            intent.putExtra("ID", patientId)
            println(clinic.id)
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = clinics.size
}
